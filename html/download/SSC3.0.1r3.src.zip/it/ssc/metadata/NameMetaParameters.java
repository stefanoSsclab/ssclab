package it.ssc.metadata;

public interface NameMetaParameters {
	
	public enum NAME_META_PARAMETERS {
		NOBS_LONG};

}
