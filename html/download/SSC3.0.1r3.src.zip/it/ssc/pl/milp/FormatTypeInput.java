package it.ssc.pl.milp;

public interface FormatTypeInput {
	
	public enum FormatType {
		/**
		 * Per definire un vincolo del tipo = 
		 */
		SPARSE,
		COEFF
		
	}

}
