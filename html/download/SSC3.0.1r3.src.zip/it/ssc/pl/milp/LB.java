package it.ssc.pl.milp;

 class LB  {
	 double value;
	 MilpManager milp;
}
