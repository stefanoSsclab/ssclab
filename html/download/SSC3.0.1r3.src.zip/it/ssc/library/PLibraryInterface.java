package it.ssc.library;

public interface PLibraryInterface extends Library {
	
	void closeLibraryForTerminateSession() throws Exception;

}
