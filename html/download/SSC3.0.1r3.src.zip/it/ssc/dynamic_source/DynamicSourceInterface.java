package it.ssc.dynamic_source;

public interface DynamicSourceInterface {
	
	 String getUserSource() ;
	
	 String createCompleteJavaClassSource(String name_class) ;

}
