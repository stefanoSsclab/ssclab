package it.ssc.parser.exception;

public class InvalidDateFormatException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidDateFormatException(String message) {
		super(message);
	}

}
