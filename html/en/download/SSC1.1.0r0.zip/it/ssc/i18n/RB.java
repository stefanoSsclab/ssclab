package it.ssc.i18n;

import java.util.ResourceBundle;

public class RB {
	public static  ResourceBundle msg; 
	
	
	static { 
		msg= ResourceBundle.getBundle("MessagesBundle");
	}
	
	public static void main(String arg[]) {
		System.out.println(msg.getString("allarme"));
	}
}
