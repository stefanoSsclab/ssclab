package it.ssc.i18n;

import static it.ssc.i18n.RB.msg;

public class Prova {
	
	public static void main(String arg[]) {
		System.out.println(msg.getString("allarme")); 
	}
	
}
