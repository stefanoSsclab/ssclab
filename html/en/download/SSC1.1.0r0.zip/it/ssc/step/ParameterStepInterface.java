package it.ssc.step;

public interface ParameterStepInterface {
	
	public void setParamAttribute(java.lang.String name, java.lang.Object value);
	
	public java.lang.Object getParamAttribute(java.lang.String name);
	
	

}
