package it.ssc.context.exception;

import static it.ssc.i18n.RB.msg;

public class InvalidSessionException  extends Exception  {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidSessionException ()  {
		super( msg.getString("it.ssc.context.exception.InvalidSessionException.msg1"));
	}
}
