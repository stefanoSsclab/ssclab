package it.ssc.dataset.exception;

import static it.ssc.i18n.RB.msg;
public class InvalidNameDataset extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidNameDataset(String name_ds) {
		super(msg.getString("it.ssc.dataset.exception.InvalidNameDataset.msg1")+name_ds);
	}
}
