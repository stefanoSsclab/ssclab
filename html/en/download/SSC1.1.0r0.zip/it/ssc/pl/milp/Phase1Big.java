package it.ssc.pl.milp;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.util.logging.Logger;

import it.ssc.log.SscLevel;
import it.ssc.log.SscLogger;
import it.ssc.vector_spaces.Matrix;
import it.ssc.vector_spaces.Vector;

class Phase1Big extends Phase0Big {
	
	private static final Logger logger=SscLogger.getLogger();
	
	private Matrix A; 
	private Vector B;
	private final int n;
	private final int m;
	private Matrix table_exended_pulish;
	private boolean isMilp=false;
	
	public Phase1Big(Matrix A, Vector B,BIGEPSILON epsilon,BIGEPSILON cepsilon) throws SimplexException {
		
		super(A.getNrow(), A.getNcolumn() + A.getNrow(),epsilon,cepsilon);
		
		this.m=A.getNrow();
		this.n=A.getNcolumn();
		
		if(B.getTipo()==Vector.TYPE_VECTOR.ROW) { 
			B.traspose();
		}
		if(m!=B.lenght()) {
			throw new SimplexException("Il numero di righe di A (matrice dei coefficienti) non si adatta al numero di componenti del vettore B dei termini noti");
		}
		//matrice dei coefficienti dei vincoli
		this.A=A;
		//vettore dei termini noti
		this.B=B;
		//tabella estesa
		this.table_exended=createTablePhase1();
	}
	
	public void setMilp(boolean isMilp) {
		this.isMilp = isMilp;
	}

	
	private BigDecimal calcNewValueZ() {
		BigDecimal init_z=ZERO_BIG;
		for (int i = 0; i < m ; i++) {
			init_z=init_z.add(B.getBigCell(i), MathContext.DECIMAL128);
		}
		return init_z;
	}
	
	private Vector calcNewCoefficienti() {
		Vector C2=new Vector(n,Vector.TYPE_VECTOR.ROW);
		for (int i = 0; i < m ; i++) {
			for (int j = 0; j < n ; j++) {
				//if(i == 0) C2.setBigCell(j,ZERO_BIG);
				C2.setBigCell(j,C2.getBigCell(j).add(A.getBigCell(i, j), MathContext.DECIMAL128))	;
			}
		}   
		return C2;
	}
	
	
	private Matrix createTablePhase1() {
		
		Vector C2=calcNewCoefficienti();
		BigDecimal z_init= calcNewValueZ();
		
		Matrix table = new Matrix(m+1,n +m +1);
		basis = new int[m];
		
		//MATRICE ORIGINALE
		for (int i = 0; i < m ; i++) {
			for (int j = 0; j < n ; j++) {
				table.setBigCell(i,j,A.getBigCell(i, j));
			}
		}    
		//VARIABILI SLACKS - B - BASE 
		for (int i = 0; i < m ; i++) {
			table.setBigCell(i,n + i,ONE_BIG);
			table.setBigCell(i,m + n,  B.getBigCell(i)); //new 
			setBases(i,n+i); 
		}
		
		for (int j = 0; j < n ; j++) {
			table.setBigCell(m ,j,  C2.getBigCell(j));
		}
		
		table.setBigCell(m ,m+n,z_init);
		return table;
	}
	

	public Matrix getTableExtended() {
		return this.table_exended;
	}


	public SolutionType resolve(long num_iteration)  {
		
		//printTable();
		
		long LOCAL_NUM_MAX_ITERATION=NUM_MAX_ITERATION;
		if(num_iteration > 0) LOCAL_NUM_MAX_ITERATION=num_iteration;
	
		int var_incoming=0,row_var_outgoing=0;
		SolutionType solution=SolutionType.MAX_ITERATIUM; 
		
		for(  ;this.iteration < LOCAL_NUM_MAX_ITERATION;  this.iteration++) {
			
			if(isBaseDegenerate())  var_incoming = test_var_incoming_bland();
			else var_incoming = test_var_incoming();
			
			if (var_incoming == -1) {	
				solution= SolutionType.OPTIMUM; 
				break;
			} 
			
			if ((row_var_outgoing = test_var_outgoing(var_incoming)) == -1) { 
				solution= SolutionType.ILLIMITATUM;
				break;
			}

			pivoting(row_var_outgoing,var_incoming);
			setBases(row_var_outgoing,var_incoming);
			
			//printTable();
			//printBases();
		}
		
		if(solution== SolutionType.MAX_ITERATIUM) logger.log(SscLevel.TIME,"Raggiunto il massimo numero di iterazioni "+(LOCAL_NUM_MAX_ITERATION));
		
		BigDecimal z=getValueZ();
		if(!isMilp) {
			logger.log(SscLevel.INFO,"Valore funzione obiettivo fase Uno :"+(z.doubleValue()));
			logger.log(SscLevel.NOTE,"Valore epsilon fissato per la convergenza della fase Uno :"+cepsilon.getValue());
		}
		if(solution== SolutionType.OPTIMUM && (z.compareTo(cepsilon.getValue()) > 0 || z.compareTo(cepsilon.getValue().negate(MathContext.DECIMAL128)) < 0))   {
			if(!isMilp) logger.log(SscLevel.NOTE,"Il valore epsilon per la convergenza fase Uno puo' essere modificato tramite il metodo setCEpsilon()");
			return SolutionType.VUOTUM;
		}	
		else return solution;
		
	}
	
	public void pulish() {
		//se c'e' una variabile ausiliaria in base (naturalmente degenere) si fa uscire 
		//se quelle presenti hanno zero sulle variabili reali.  Si tolgono le righe 

		// si cancellano le colonne relative alla ausiliarie  
		exitAuxFromBase();
		Matrix table_pulish=deleteRowAux(table_exended);
		this.table_exended_pulish=deleteColumnAux(table_pulish);

	}
   
   public Matrix getTablePulishClone() throws CloneNotSupportedException {
	   if(this.table_exended_pulish!=null) return  this.table_exended_pulish.clone();
	   else return null;
   }
   
   private Matrix deleteRowAux(Matrix table_pulish) {
	   
		int index_aux_out = 0;
		while (((index_aux_out = existAuxBase()) != -1) && ifAllCoeffZeroAux(index_aux_out)) {
			table_pulish=deleteSingleRowAux(index_aux_out,table_pulish);
			updateBase(index_aux_out);
			//System.out.println("Cancellata riga var ausiliare con aij a zero");
		}
	    return table_pulish;
   }
   
   
   private void updateBase(int row_canc ) {
	   int new_basis[]=new int[basis.length-1];
	   int index_row = 0;
	   for (int i = 0; i < basis.length; i++) {
		   if (row_canc==i) continue;
		   new_basis[index_row]=basis[i] ;
		   index_row++;
	   }
	   basis=new_basis;
   }
   
   private Matrix deleteSingleRowAux(int row_canc , Matrix table_pulish) {
		int n_row = table_pulish.getNrow();
		Matrix table = new Matrix(n_row-1, n +m+ 1);

		int index_row = 0;
		for (int i = 0; i < n_row; i++) {
			if (row_canc==i) continue;
			
			for (int j = 0; j <= n + m; j++) {
				table.setBigCell(index_row, j, table_pulish.getBigCell(i, j));
			}
			index_row++;
		}
		return table;
	   
   }
   
   private boolean ifAllCoeffZeroAux(int index) {
	   for (int j = 0; j < n ; j++) {
		   if(table_exended.getBigCell(index,j).setScale(SCALE, RoundingMode.HALF_DOWN).compareTo(ZERO_BIG) != 0) {
		   //if(!(table_exended.getBigCell(index,j).compareTo(epsilon.getValue()) < 0 
			//	&& table_exended.getBigCell(index,j).compareTo(epsilon.getValue().negate(MathContext.DECIMAL128)) > 0 )) {
			   return false;
		   }
	   }
	   return true;
   }
   
   //non tocca numero righe o colonne
	private void exitAuxFromBase() {
		int index_aux_out = 0, index_orig_in = 0;
		while (((index_aux_out = existAuxBase()) != -1) && ((index_orig_in = existVarOrigOutBase(index_aux_out)) != -1)) {
			pivoting(index_aux_out, index_orig_in);
			setBases(index_aux_out,index_orig_in);
			//System.out.println("---------------->>>>>>> Fatta uscire variabile ausiliaria "+index_aux_out);
		}
	}
   
   private int existVarOrigOutBase(int index_aux) {
	   for (int j = 0; j < n ; j++) {
		   if (!(table_exended.getBigCell(index_aux,j).setScale(SCALE, RoundingMode.HALF_DOWN).compareTo(ZERO_BIG) == 0))  {
		  // if (!( table_exended.getBigCell(index_aux,j).compareTo(epsilon.getValue()) < 0 
		//		 && table_exended.getBigCell(index_aux,j).compareTo(epsilon.getValue().negate(MathContext.DECIMAL128)) >0)  )  {
			   return j;
		   }
	   }
	   return -1;
   }
   
   private int existAuxBase() {
	   for (int i = 0; i < basis.length; i++) {
			if(basis[i] >= n) return i ;
		}
	   return -1;
   }
   
   
	private Matrix deleteColumnAux(Matrix A_all_col) {
		int n_row = A_all_col.getNrow();
		Matrix table = new Matrix(n_row, n + 1);
	
		for (int i = 0; i < n_row; i++) {
			int index_col = 0;
			for (int j = 0; j <= n + m; j++) {
				if (!(j < n || j == n + m)) continue;
				table.setBigCell(i, index_col, A_all_col.getBigCell(i, j));
				index_col++;
			}
		}
		return table;
	}

}
