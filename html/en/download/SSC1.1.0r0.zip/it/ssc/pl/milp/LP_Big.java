package it.ssc.pl.milp;

import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import it.ssc.context.Context;
import it.ssc.context.Session;
import it.ssc.context.exception.InvalidSessionException;
import it.ssc.datasource.DataSource;
import it.ssc.log.SscLevel;
import it.ssc.log.SscLogger;
import it.ssc.ref.Input;
import it.ssc.vector_spaces.MatrixException;

 class LP_Big {
	
	private static final Logger logger=SscLogger.getLogger();
	
	private MilpProblem milp_original;
	private SolutionImpl solution_pl;
	private int num_max_iteration=-1;
	private double[][] A;
	private double[]   B;
	private double[]   C;
	private Session session;
	private BIGEPSILON epsilon=BIGEPSILON.E1_M20;
	private BIGEPSILON cepsilon=BIGEPSILON.E1_M20;
	

	/*Mettere warning se ci sono vincoli interi non eseguibili*/ 
	
	public LP_Big(LinearObjectiveFunction f,ArrayList<Constraint> constraints) throws Exception {
		
		boolean isMilp=false;
		
		milp_original=CreateMilpProblem.create(f,constraints,isMilp);
		milp_original.configureInteger();
		MilpProblem milp_standard=milp_original.clone(); 
		milp_standard.standardize(); 
		
		A=milp_standard.getMatrixA();
		B=milp_standard.getVectorB();
		C=milp_standard.getVectorC();
	}

	public void seEpsilon(BIGEPSILON b_epsilon) {
		this.epsilon=b_epsilon;
	}
	
	public void seCEpsilon(BIGEPSILON b_epsilon) {
		this.cepsilon=b_epsilon;
	}

	public LP_Big(Input milp_input) throws InvalidSessionException, Exception {
		
		this(milp_input, Context.createNewSession());
		logger.log(Level.INFO,"Fine utilizzo sessione SSC per importazione dati."); 
		session.close(); 
	}
	
	public LP_Big(Input milp_input,Session session) throws InvalidSessionException, Exception {
		
		this.session=session;
		DataSource milp_data_source=session.createDataSource(milp_input);
		boolean isMilp=false;
		milp_original=CreateMilpProblem.create(milp_data_source,isMilp);
		milp_original.configureInteger();
		
		MilpProblem milp_standard=milp_original.clone();
		milp_standard.standardize(); 
		
		A=milp_standard.getMatrixA();
		B=milp_standard.getVectorB();
		C=milp_standard.getVectorC();
		
	}
	public void setMaxIteration(int num_max_iteration) throws SimplexException  {
		if(num_max_iteration <= 0) throw new SimplexException("Il numero massimo di iterazioni deve essere un numero positivo");
		this.num_max_iteration=num_max_iteration;
	}
	
	public SolutionType resolve() throws SimplexException, MatrixException, CloneNotSupportedException {
		SimplexInterface simplex = null;
		simplex=new SimplexBig(A, B, C,epsilon,cepsilon);
		simplex.setNumIterationMax(num_max_iteration);
		logger.log(SscLevel.INFO,"Risulta attivo utilizzo dei BigDecimal sulla tabella estesa per il calcolo del Simplesso");
		
		
		long start=System.currentTimeMillis();
		SolutionType type_solution=simplex.phaseOne();
		long end_phase_one=System.currentTimeMillis();
		long end_phase_two=end_phase_one;
		
		
		logger.log(SscLevel.TIME,"Durata fase Uno Simplesso in "+(end_phase_one-start)+" millisecondi");
		logger.log(SscLevel.INFO,"Numero iterazioni fase Uno Simplesso :"+simplex.getNumIterationPhaseOne());
		
		if(type_solution==SolutionType.OPTIMUM) {
			type_solution =simplex.phaseTwo();
			end_phase_two=System.currentTimeMillis();
			logger.log(SscLevel.TIME,"Durata fase Due Simplesso in "+(end_phase_two-end_phase_one)+" millisecondi");
			logger.log(SscLevel.INFO,"Numero iterazioni totali (fase Uno + fase Due)  Simplesso :"+simplex.getNumIterationPhaseTotal());
			this.solution_pl=new SolutionImpl(type_solution,
											milp_original.clone(),
											simplex.getFinalBasisClone(),
											simplex.getFinalValuesBasisClone()
											);
			
		}	
		logger.log(SscLevel.TIME,"Durata totale Simplesso in "+(end_phase_two-start)+" millisecondi");
		return type_solution;

	}
	
	public double[][] getStandartMatrixA() {
		return A.clone();
	}

	public double[] getStandartMatrixB() {
		return B.clone();
	}

	public double[] getStandartMatrixC() {
		return C.clone();
	}

	public Solution getSolution()  {
		return this.solution_pl;
	}
	
	
	//devo verificare se e' un PL mix, ovvero se esistono variabili dichiarate integer o binary
	
	//se binary attuo branch and bound 
	//se binary, upper bound e lower bound non devono essere valorizzati (fatto)
	//se binary non puo' essere integer (fatto)
	//se binary la variabile non si trasforma ma esiste solo vincolo x <=1
	
	//se binary valutare se impostare lower e upper a 0,1. 
	
	//se integer attuo branch and bound
	//se integer, upper bound e lower bound possono essere valorizzati, ma devono essere interi (fatto)
	//se lower bound negativo o missing , si trasforma la variabile in y1 - y2
	//se integer non puo' essere binary  (fatto)
	
	//se real non attuo branche and bound
	//il lower e l'upper sono sempre considerati compresi nei limiti 
	//se lower e l'upper entrambi missimg, si considera variabile libera
	
	//se la funzione e' min, cambio di segno ai coefficienti 
	//se c'e' un vincolo di maggiore uguale si inserisce variabile -y1
	
	
	

	
	

}
