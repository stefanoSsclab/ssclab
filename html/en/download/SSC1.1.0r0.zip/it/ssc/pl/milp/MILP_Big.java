package it.ssc.pl.milp;

import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import it.ssc.context.Context;
import it.ssc.context.Session;
import it.ssc.context.exception.InvalidSessionException;
import it.ssc.log.SscLevel;
import it.ssc.log.SscLogger;
import it.ssc.pl.milp.ManagerMILP.VERSUS_SEPARATION;
import it.ssc.ref.Input;
import it.ssc.vector_spaces.MatrixException;

class MILP_Big {
	
	
	/**
	 * 1) Recupero il problema in forma standart  (Po) e mo lo metto da parte
	 * 2) Recupero il vettore delle variabili per capire quali devono essere 
	 *    integer o binary; 
	 * 3) Valorizzo il LB a -oo . 
	 * 4) Creo una copia del problema  iniziale e tolgo i requisiti di interezza
	 *    delle variabili, lasciando quelli di upper o lower (nel caso del binary [0,1] ) . 
	 *    Questo rilasciamento lo chiamiamo Po'. Lo risolvo, se la regione ammissibile � vuota. -> .
	 *    Cancello il nodo. Se tutti i nodi sono cancellati , vedo se esiste un LB != -oo.
	 *    Se esiste una soluzione occorre verificare se le variabili che devono essere intere lo sono. Se lo
	 *    sono STOP , soluzione ottima intera trovata.   
	 *    
	 * @throws Exception 
	 * @throws InvalidSessionException 
	 */
	
	
	/*
	 * 2) Verificare che il periodo di durata massima sia ben calcolato sia sul MILP che sull LP 
	 * 3) Verificare che i log siano congruenti come sequenza di apparizzione 
	 * 4) Mettere a posto le exception non propagate dai CLONI 
	 * 
	 */
	
	private static final BIGEPSILON b_epsilon=BIGEPSILON.E1_M20;
	private static final EPSILON iepsilon=EPSILON._1E_M13; 
	private static final BIGEPSILON cb_epsilon=BIGEPSILON.E1_M20;
	
	private static final Logger logger=SscLogger.getLogger(); 
	
	private ManagerMILP milp_initiale;
	private LB lb;
	private static final boolean isBig=true;
	

	public MILP_Big(LinearObjectiveFunction f,ArrayList<Constraint> constraints) throws InvalidSessionException, Exception {
		this.milp_initiale = new ManagerMILP(f, constraints);
		lb=new LB();
		
		setAllEpsilon();
	}
	
	public MILP_Big(Input milp_input) throws InvalidSessionException, Exception {
		Session session=Context.createNewSession();
		this.milp_initiale = new ManagerMILP(milp_input, session); 
		logger.log(Level.INFO,"Fine utilizzo sessione SSC per importazione dati.");
		session.close();
		lb=new LB();
		
		setAllEpsilon();
	}
	
	public MILP_Big(Input milp_input,Session session) throws InvalidSessionException, Exception {
		
		this.milp_initiale = new ManagerMILP(milp_input, session); 
		lb=new LB();
		
		setAllEpsilon();
	}
	
	private void setAllEpsilon() {
		this.milp_initiale.setBigEpsilon(b_epsilon);
		this.milp_initiale.setIEpsilon(iepsilon); 
		this.milp_initiale.setBigCEpsilon(cb_epsilon); 
	}
	
	
	public void setBigEpsilon(BIGEPSILON b_epsilon1) {
		this.milp_initiale.setBigEpsilon(b_epsilon1);
	}
	
	public void setIEpsilon(EPSILON epsilon1) {
		this.milp_initiale.setIEpsilon(epsilon1); 
	}
	
	public void setBigCEpsilon(BIGEPSILON cb_epsilon1) {
		this.milp_initiale.setBigCEpsilon(cb_epsilon1);
	}
	
	
	public SolutionType resolve() throws SimplexException, MatrixException, CloneNotSupportedException, LPException {
		
		
		int num_simplex_resolved=1;
		long start=System.currentTimeMillis();
		
		ManagerMILP milp_current=milp_initiale;
		Tree tree=new Tree();
		
		SolutionType type_solution_initial=milp_current.resolve(isBig); 
		lb.value=Double.NEGATIVE_INFINITY; 
		if(type_solution_initial==SolutionType.OPTIMUM) {
			tree.addNode(milp_current);
		}	 
		
		
		SolutionType type_solution=SolutionType.VUOTUM;
		while(!tree.isEmpty()) {
			milp_current=tree.getMilpBestUP();
			//System.out.println("prob:"+milp_current.getId()+" z:"+milp_current.getUP());
			if(milp_current.isSolutionIntegerAmmisible()) {
				//System.out.println("SOLUZIONE INTERA:"+milp_current.getId()+" z:"+milp_current.getUP());
				if(lb.value < milp_current.getOptimumValue()) {
					//System.out.println("SOLUZIONE INTERA MIGLIORE:"+milp_current.getId()+" z:"+milp_current.getUP());
					lb.value= milp_current.getOptimumValue();
					lb.milp=milp_current;
					type_solution=SolutionType.OPTIMUM; 
					milp_current.setIntegerIfOptimal(); 
				}
			}
			else {
				int index_var_not_integer=milp_current.getIndexVarToBeInteger();
				//System.out.println("DIVIDO PROBLEMA ID:"+milp_current.getId()+" z:"+milp_current.getUP());
				ManagerMILP milp_sotto=milp_current.getCloneBySeparation(index_var_not_integer, VERSUS_SEPARATION.MINOR);
				ManagerMILP milp_sopra=milp_current.getCloneBySeparation(index_var_not_integer, VERSUS_SEPARATION.MAJOR);

				SolutionType type_solution_sotto=milp_sotto.resolve(isBig);
				num_simplex_resolved++;
				if(type_solution_sotto==SolutionType.OPTIMUM) {
					//System.out.println("OTTIMO SOTTO ID:"+milp_sotto.getId()+" z:"+milp_sotto.getUP());
					tree.addNode(milp_sotto);
				}
				
				SolutionType type_solution_sopra=milp_sopra.resolve(isBig); //valutaree se un pi� thread
				num_simplex_resolved++;
				if(type_solution_sopra==SolutionType.OPTIMUM) {
					//System.out.println("OTTIMO SOPRA ID:"+milp_sopra.getId()+" z:"+milp_sopra.getUP());
					tree.addNode(milp_sopra);
				}
				tree.deleteNodeWhitUPnotValide(lb.value); 
			}
			tree.deleteNode(milp_current);
		}
		
		long end=System.currentTimeMillis();
		logger.log(SscLevel.TIME,"Durata processo BRANCH AND BOUND "+(end-start)+" millisecondi");
		logger.log(SscLevel.INFO,"Numero di simplessi eseguiti sui nodi : "+num_simplex_resolved);
		return type_solution;

	}
	
	public Solution getSolution()  {
		if(lb.milp!=null) return lb.milp.getSolution();
		else return null;
		
	}
}
