package it.ssc.pl.milp;

/**
 * Questa classe permette di costruire oggetti ognuno dei quali rappresenta un vincolo per  
 * un problema di LP espresso nella notazione matriciale
 * 
 * @author Stefano Scarioli 
 * @version 1.0
 * @see <a target="_new" href="http://www.ssclab.org">SSC Software www.sscLab.org</a>
 */



public class Constraint {
	private Double[] Aj;
	private ConsType rel;
	private Double bi;
	
	/**
	 * 
	 * @param Aj La parte LHS del j-esimo vincolo del problema
	 * @param rel Il tipo  di vincolo (relazione) definito (EQ,LE,GE)
	 * @param rhs La parte RHS del vincolo o coefficiente bj 
	 * @throws SimplexException Se il vincolo non &egrave; congruente 
	 */
	
	public Constraint(Double[] Aj, ConsType rel, Double rhs) throws SimplexException {
		if(Aj==null) throw new SimplexException("Il vettore riga Aj del vincolo e' a null");
		this.Aj=Aj;
		if(rel==null) throw new SimplexException("Il tipo di relazione sul vincolo e' a null");
		this.rel=rel;
		this.bi=rhs;
	}
	/**
	 * 
	 * @param Aj La parte LHS del j-esimo vincolo del problema
	 * @param rel Il tipo  di vincolo (relazione) definito (EQ,LE,GE)
	 * @param rhs La parte RHS del vincolo o coefficiente bj 
	 * @throws SimplexException Se il vincolo non &egrave; congruente 
	 */
	
	public Constraint(double[] Aj, ConsType rel, Double rhs) throws SimplexException {
		if(Aj==null) throw new SimplexException("Il vettore riga Aj del vincolo e' a null");
		Double[] Ajj=new Double[Aj.length];
		for(int _a=0;_a<Aj.length;_a++) {
			Ajj[_a]=Aj[_a];
		}
		this.Aj=Ajj;
		if(rel==null) throw new SimplexException("Il tipo di relazione sul vincolo e' a null");
		this.rel=rel;
		this.bi=rhs;
	}
	
	/**
	 * 
	 * @return La parte LHS del j-esimo vincolo del problema
	 */

	public Double[] getAj() {
		return Aj;
	}
	/**
	 * 
	 * @return Il tipo  di vincolo (relazione) definito (EQ,LE,GE)
	 */

	public ConsType getRel() {
		return rel;
	}
	/**
	 * 
	 * @return La parte RHS del vincolo o coefficiente bj 
	 */

	public Double getRhs() {
		return bi;
	}
}
