package it.ssc.pl.milp;

import it.ssc.vector_spaces.Matrix;
import java.math.BigDecimal;
import java.math.MathContext;

abstract class Phase0Big {
	
	public static final BigDecimal ZERO_BIG=   new BigDecimal("0.0",MathContext.DECIMAL128);
	public static final BigDecimal ONE_BIG=    new BigDecimal("1.0",MathContext.DECIMAL128);
	public static final BigDecimal NEG_ONE_BIG=new BigDecimal("-1.0",MathContext.DECIMAL128);	
	public static final int SCALE=20;
	protected long NUM_MAX_ITERATION=100000;
	
	protected int basis[];
	protected Matrix table_exended;
	protected long iteration =0; 
	
	protected BIGEPSILON epsilon;
	protected BIGEPSILON cepsilon;
	
	private final int _M;
	private final int _N;
	
	protected Phase0Big(int _M, int _N,BIGEPSILON epsilon,BIGEPSILON cepsilon) {
		this._M=_M; //righe 
		this._N=_N; //colonne
		this.epsilon=epsilon;
		this.cepsilon=cepsilon;
	}
	
	protected Phase0Big(int _M, int _N,BIGEPSILON epsilon) {
		this._M=_M; //righe 
		this._N=_N; //colonne
		this.epsilon=epsilon;
	}
	
	public long getNumIteration() {
		return iteration;
	}
	
	public abstract SolutionType resolve(long num_iteration) ;
	
	protected void setBases(int row,int in) {
		basis[row] = in;
	}

	
	public BigDecimal getValueZ() {
		//System.out.println("CC"+table_exended.getBigCell(_M, _N).doubleValue());
		//System.out.println("CC"+table_exended.getBigCell(_M, _N).setScale(SCALE, RoundingMode.HALF_DOWN).doubleValue());
		return  table_exended.getBigCell(_M, _N).negate(MathContext.DECIMAL128);
	}
	
	
	protected void pivoting(int out, int in) {
		
		BigDecimal value;
		for (int i = 0; i <= _M; i++) {
			for (int j = 0; j <= _N; j++) {
				if (i != out && j != in) {
					
					if(table_exended.getBigCell(i, in).compareTo(ZERO_BIG ) ==0  || table_exended.getBigCell(out, j).compareTo(ZERO_BIG ) ==0) {
						value= ZERO_BIG;
					}
					else {
						value = table_exended.getBigCell(out, j).multiply(table_exended.getBigCell(i, in),MathContext.DECIMAL128);
						value = value.divide(table_exended.getBigCell(out, in),	MathContext.DECIMAL128);
					}

					value = table_exended.getBigCell(i, j).subtract(value,  MathContext.DECIMAL128);
					table_exended.setBigCell(i, j, value);
					
				}
			}
		}
		

		for (int i = 0; i <= _M; i++) {
			if (i != out) {
				table_exended.setBigCell(i, in, ZERO_BIG);
			}
		}

		for (int j = 0; j <= _N; j++) {
			if (j != in) {
				value = table_exended.getBigCell(out, j).divide(table_exended.getBigCell(out, in),MathContext.DECIMAL128);
				table_exended.setBigCell(out, j, value);
			}
		}
		table_exended.setBigCell(out, in, ONE_BIG);
	}
	

	protected int test_var_outgoing(int var_incoming) {
		int row_var_outgoing = -1;
		BigDecimal bottleneck= null, candidate_bottleneck=null;
		for (int i = 0; i < _M; i++) {
			//if (table_exended.getBigCell(i, var_incoming).setScale(SCALE, RoundingMode.HALF_DOWN).compareTo(ZERO_BIG) <= 0) {
			if (table_exended.getBigCell(i, var_incoming).compareTo(epsilon.getValue()) <= 0) {
				continue;
			}
			
			candidate_bottleneck = table_exended.getBigCell(i, _N).divide(
					               table_exended.getBigCell(i, var_incoming),MathContext.DECIMAL128);

			if (row_var_outgoing == -1) {
				row_var_outgoing = i;
				bottleneck = candidate_bottleneck;
			}
			else  if (candidate_bottleneck.compareTo(bottleneck) == -1) {
				row_var_outgoing = i;
				bottleneck = candidate_bottleneck;
			}
		}
		return row_var_outgoing;
	}
	
	
	protected int test_var_incoming() {
		BigDecimal value_var_incoming=ZERO_BIG;
		int index_var_incoming = 0;
		for (int j = 0; j < _N; j++) {
			//controllo se c'e' un qualche coefficente sull f.o. maggiore di ZERO
			//naturalmente relativo alle variabili non basiche
			if (table_exended.getBigCell(_M, j).compareTo(value_var_incoming) > 0) { 
				value_var_incoming = table_exended.getBigCell(_M, j);
				index_var_incoming = j;
			}
		}

		//if (value_var_incoming.setScale(SCALE, RoundingMode.HALF_DOWN).compareTo(ZERO_BIG) > 0) return index_var_incoming;
		if (value_var_incoming.compareTo(epsilon.getValue()) > 0) return index_var_incoming;
		else return -1;  // optimal
	}
	
	protected int test_var_incoming_bland() {
		for (int j = 0; j < _N; j++) {
			 //controllo se c'e' un qualche coefficente sull f.o. maggiore di ZERO
	    	 //naturalmente relativo alle variabili non basiche
			if (table_exended.getBigCell(_M, j).compareTo(epsilon.getValue()) > 0) {
				return j;
			}
		}
		return -1; // optimal
	}
	
	
	
	protected  boolean isBaseDegenerate() {
		int m=table_exended.getNrow()-1;
		int n_m=table_exended.getNcolumn()-1;
		BigDecimal value;
		for (int i = 0; i < m; i++) {
			value=table_exended.getBigCell(i,n_m);
			//if(value.setScale(SCALE, RoundingMode.HALF_DOWN).compareTo(ZERO_BIG)==0) return true;
			if(value.compareTo(epsilon.getValue()) < 0 && value.compareTo(epsilon.getValue().negate(MathContext.DECIMAL128)) > 0) return true;
		}
		return false;
	}
	
	public void printTable() {
		for(int _i=0;_i<table_exended.getNrow();_i++) {
			System.out.println("");
			for(int _j=0;_j<table_exended.getNcolumn();_j++) {
				double val=table_exended.getCell(_i, _j);
				System.out.printf("\t : %7.2f",val);
			}
		}
	}

	public void printBases() {
		
		System.out.println("F2 dim:" + basis.length);
		for (int i = 0; i < basis.length; i++) {
			System.out.println("F2 X" + (basis[i]+1));
		}
	}
	
	 public int[] getBasisClone() {
		   return basis.clone();
	   }
}
