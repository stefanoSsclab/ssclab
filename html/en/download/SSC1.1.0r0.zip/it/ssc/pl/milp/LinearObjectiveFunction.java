package it.ssc.pl.milp;

/**
 * Questa classe permette di istanziare oggetti che rappresentano la funzione obiettivo 
 * in problemi di LP espressi nella notazione matriciale e a disequazioni 
 * 
 * @author Stefano Scarioli
 * @version 1.0
 * @see <a target="_new" href="http://www.ssclab.org">SSC Software www.sscLab.org</a>
 *
 */

public class LinearObjectiveFunction {
	
	private GoalType type;
	private double[] C;
	
	/**
	 * 
	 * @return il tipo di ottimizzazione (MAX o MIN)
	 */
	
	public GoalType getType() {
		return type;
	}
	/**
	 * 
	 * @return il vettore dei coefficienti della funzione obiettivo 
	 */

	public double[] getC() {
		return C;
	}
	/**
	 * Costruttore 
	 * 
	 * @param C Il vettore dei coefficienti della funzione obiettivo
	 * @param type Il tipo di ottimizzazione (MAX o MIN) come istanza della enumerazione GoalType
	 * @throws LPException Se i parametri sono incongruenti con il problema
	 */

	public LinearObjectiveFunction(double[] C, GoalType type) throws  LPException {
		if(type==null) throw new LPException("Il GoalType della funzione obiettivo e' a null");
		this.type=type;
		if(C==null) throw new LPException("Il vettore C dei coefficienti della funzione obiettivo e' a null");
		this.C=C;
	}

}
