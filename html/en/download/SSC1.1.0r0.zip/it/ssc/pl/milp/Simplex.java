package it.ssc.pl.milp;

import it.ssc.vector_spaces.Matrixe;
import it.ssc.log.SscLogger;
import it.ssc.vector_spaces.MatrixException;
import it.ssc.vector_spaces.Vectore;

import java.math.BigDecimal;
import java.math.MathContext;
import java.util.logging.Logger;

 class Simplex implements SimplexInterface {
	
	static final BigDecimal ZERO_BIG=new BigDecimal("0.0",MathContext.DECIMAL128);
	static final BigDecimal ONE_BIG=new BigDecimal("1.0",MathContext.DECIMAL128);
	
	private Matrixe A;
	private Vectore B;
	private Vectore C;
	private int n; 
	private int m; 
	
	private EPSILON epsilon;
	private EPSILON cepsilon;
	
	private boolean isMilp=false;

	public void setMilp(boolean isMilp) {
		this.isMilp = isMilp;
	}

	private SolutionType type_solution_phase_one=null;
	private SolutionType type_solution_phase_two=null;
	private Phase1 phase_one;
	private int basis[];
	private double values_basis[];
	private long num_iteration_max;
	private long num_iteration_phase_one;
	private long num_iteration_phase_total;
	
	
	public Simplex(double[][] A, double[] B, double[] C,EPSILON epsilon, EPSILON cepsilon) throws SimplexException, MatrixException {
		this(new Matrixe(A), new Vectore(B), new Vectore(C),epsilon,cepsilon);
	}
	
	public Simplex(Matrixe A, Vectore B, Vectore C,EPSILON epsilon,EPSILON cepsilon) throws SimplexException {
		
		this.epsilon=epsilon;
		this.cepsilon=cepsilon;
		
		this.m=A.getNrow();
		this.n=A.getNcolumn();
		
		if(B.getTipo() == Vectore.TYPE_VECTOR.ROW) {
			B.traspose();
		}
		if(C.getTipo() == Vectore.TYPE_VECTOR.COLUMN) {
			C.traspose();
		}
		if(m!=B.lenght()) {
			throw new SimplexException("Il numero di righe di A (matrice dei coefficienti) non si adatta al numero di componenti del vettore B dei termini noti");
		}
		if(n!=C.lenght()) {
			throw new SimplexException("Il numero di colonne di A (matrice dei coefficienti) non si adatta al numero di componenti del vettore C della funzione obiettivo");
		}
		//matrice dei coefficienti dei vincoli
		this.A=A;
		//vettore dei termini noti
		this.B=B;
		//coefficienti della funzione obiettivo
		this.C=C;
	}
	
	public void setNumIterationMax(long num_iteration_max) {
		this.num_iteration_max = num_iteration_max;
	}

	public SolutionType phaseOne()  throws SimplexException {
		phase_one=new Phase1(A,B,epsilon,cepsilon);
		phase_one.setMilp(isMilp);

		this.type_solution_phase_one=phase_one.resolve(this.num_iteration_max);
		this.num_iteration_phase_one=phase_one.getNumIteration();
		return this.type_solution_phase_one;
	}
	
	
	public long getNumIterationPhaseOne() {
		return num_iteration_phase_one;
	}

	public long getNumIterationPhaseTotal() {
		return num_iteration_phase_total;
	}

	public SolutionType phaseTwo() throws SimplexException, CloneNotSupportedException {
		
		if(this.type_solution_phase_one!=SolutionType.OPTIMUM) {
			throw new SimplexException("Attenzione, la regione ammissibile del problema e' vuota. Non esistono soluzioni !");
		}
		phase_one.pulish();
		Matrixe A_phase_one=phase_one.getTablePulishClone();
		
		Phase2 phase_two=new Phase2(A_phase_one,phase_one.getBasisClone(),C,this.num_iteration_phase_one,epsilon);
		type_solution_phase_two=phase_two.resolve(this.num_iteration_max);
		
		this.basis=phase_two.getBasisClone();
		this.values_basis=phase_two.getValuesBases();
		
		this.num_iteration_phase_total=phase_two.getNumIteration();
		return type_solution_phase_two;
	}
	
	public double[] getFinalValuesBasisClone() {
		return this.values_basis.clone();
	}
	
	public int[] getFinalBasisClone() {
		return this.basis.clone();
	}

}
