
package it.ssc.util;

import java.io.BufferedWriter;
import java.util.Locale;

public class Formatter {
	
	 public  Formatter(BufferedWriter a, Locale l) {
	      
	 }
	 
	 public  Formatter(BufferedWriter a) {
	     
	 }
	 
	 public void setNullPrintable(String s) {
	      
	 }
	 public void format(Object... g) {
		 
	 }
	 
	 public void close() {
		 
	 }
}