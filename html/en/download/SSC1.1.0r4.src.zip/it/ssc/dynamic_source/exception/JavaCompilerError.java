package it.ssc.dynamic_source.exception;

public class JavaCompilerError extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public JavaCompilerError(String message){
		super(message);
		
	}

}
