package it.ssc.formats;

public interface FormatsStep {
	
	public enum TYPE_FORMAT {CODE_ALPHABETIC, CODE_NUMERIC, CODE_NUMERIC_RANGE}; 
	
	public void setSpecific(TYPE_FORMAT code,String field_name_format,String filed_name_value, 
							    String filed_name_condition,String filed_name_value2,String filed_name_label); 
	
	public void setNamesFormatsToLoading(String... format_names_to_be_loaded);
	
	public void execute() throws Exception;

}
