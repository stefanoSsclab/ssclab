package it.ssc.step.parallel;

public interface MyRunnable extends Runnable{
	  public void run() ;
}
