package it.ssc.metadata.exception;

public class IncompatibleTypeFMT extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public IncompatibleTypeFMT(String message) {
		super(message);
	}

}
