package it.ssc.metadata.exception;

public class ReadMetadataSqlException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ReadMetadataSqlException(String message) {
		super(message);
	}
}
