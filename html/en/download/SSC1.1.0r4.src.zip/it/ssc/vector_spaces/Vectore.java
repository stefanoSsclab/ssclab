package it.ssc.vector_spaces;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;

public class Vectore {
	

	public enum TYPE_VECTOR {ROW, COLUMN};
	private TYPE_VECTOR tipo;
	private double[] big_vector;
	
	/** 
	 * Crea un vettore riga */
	public Vectore(double[]  vector) {
		this(vector,TYPE_VECTOR.ROW);
	}
	
	
	public  Vectore(int size,TYPE_VECTOR tipo) {
		this.tipo=tipo;
		big_vector=new double[size];
		//inizialize();
	}
	 
	private void inizialize() {
		for(int _a=0;_a<big_vector.length;_a++) {
			big_vector[_a]=0.0;
		}
	}	
	
	public TYPE_VECTOR getTipo() {
		return tipo;
	}
	
	public Vectore(double[] vector,TYPE_VECTOR tipo) {
		this.tipo=tipo;
		if(vector==null) throw new NullPointerException("Non posso costruire un oggetto Vector con argomento costruttore a null");
		
		big_vector=new double[vector.length];
		
		for(int _a=0;_a<vector.length;_a++) {
			
			big_vector[_a]=vector[_a];
		}
	}
	
	
	public void multiply(double scalar)  {
		for(int _a=0;_a<big_vector.length;_a++) {
			big_vector[_a]=big_vector[_a] * scalar;
		}
	}
	
	
	public double getCell(int index) {
		return big_vector[index];
	}
	
	
	public void setBigCell(int index,double value) {
		big_vector[index]=value;
	}
	
	public double getBigCell(int index) {
		return big_vector[index];
	}
	
	public int lenght() {
		return big_vector.length;
	}
	
	private static double _scalarProduct(Vectore vector0,Vectore vector1) throws VectorException {
		if(vector1==null || vector0==null ) throw new VectorException("Non posso effettuare il prodotto cartesiano con un vettore a null");
		if(vector0.lenght() != vector1.lenght())  throw new VectorException("Non posso effettuare il prodotto cartesiano su vettori di dimensioni diverse.");
		
		double scalare= 0.0;
		double single_produtc;
		for(int _a=0;_a<vector0.lenght();_a++) {
			single_produtc=vector0.big_vector[_a] * vector1.big_vector[_a];
			scalare=scalare + single_produtc;
		}
		return scalare;
	}
	
	public static double scalarProduct(Vectore vector0,Vectore vector1) throws VectorException {
		return _scalarProduct(vector0,vector1);
	}
	
	public double getNorma() throws Exception { 
		double norma_e2=_scalarProduct(this,this);
		return Math.pow( norma_e2,0.5);
	}
	
	public void traspose() { 
		if(tipo==TYPE_VECTOR.ROW) tipo=TYPE_VECTOR.COLUMN;
		else tipo=TYPE_VECTOR.ROW;
	}
}

