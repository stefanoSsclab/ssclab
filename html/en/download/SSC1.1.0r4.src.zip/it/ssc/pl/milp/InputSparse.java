package it.ssc.pl.milp;

import it.ssc.ref.Input;

/**
 * Un oggetto InputSparse va utilizzato quando per la risoluzione di un problema di LP 
 * si utilizza la notazione sparsa. In tale caso una istanza della classe Input, nel quale &egrave; presente il problema nella 
 * notazione sparsa, va usato come argomento del costruttore di questa classe e l'oggetto creato 
 * va utilizzato nel costrutore della classe LP (o MILP) : 
 * <br><br>
 * LP lp = new LP(new InputSparse(input)); 
 * 
 * @author Stefano Scarioli 
 *
 */

public class InputSparse {
	
	private Input input;
	/**
	 * Unico costruttore.  
	 * 
	 * @param input Un oggetto Input nel quale &egrave; presente un problema LP in formato sparso
	 */
	
	public InputSparse(Input input) 	{
		this.input=input;
	}
	/**
	 * 
	 * @return l'oggetto Input passato come argomento al costruttore
	 */
	
	public Input getInput() {
		return input;
	}
	
}
