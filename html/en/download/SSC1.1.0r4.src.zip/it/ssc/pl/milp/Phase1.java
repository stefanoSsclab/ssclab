package it.ssc.pl.milp;

import  it.ssc.i18n.RB;

import java.util.logging.Logger;
import it.ssc.log.SscLevel;
import it.ssc.log.SscLogger;
import it.ssc.vector_spaces.Matrixe;
import it.ssc.vector_spaces.Vectore;

class Phase1 extends Phase {
	
	private static final Logger logger=SscLogger.getLogger();
	
	private Matrixe A; 
	private Vectore B;
	private final int n;
	private final int m;
	private Matrixe table_exended_pulish;
	private boolean isMilp=false;

	
	public Phase1(Matrixe A, Vectore B,EPSILON epsilon,EPSILON cepsilon) throws SimplexException {
		
		super(A.getNrow(), A.getNcolumn() + A.getNrow(), epsilon, cepsilon);
		
		this.m=A.getNrow();
		this.n=A.getNcolumn();
		
		if(B.getTipo()==Vectore.TYPE_VECTOR.ROW) { 
			B.traspose();
		}
		if(m!=B.lenght()) {
			throw new SimplexException("Il numero di righe di A (matrice dei coefficienti) non si adatta al numero di componenti del vettore B dei termini noti");
		}
		//matrice dei coefficienti dei vincoli
		this.A=A;
		//vettore dei termini noti
		this.B=B;
		//tabella estesa
		this.table_exended=createTablePhase1();
	}
	
	public void setMilp(boolean isMilp) {
		this.isMilp = isMilp;
	}

	
	private double calcNewValueZ() {
		double init_z=0.0;
		for (int i = 0; i < m ; i++) {
			init_z=init_z+ B.getBigCell(i);
		}
		return init_z;
	}
	
	private Vectore calcNewCoefficienti() {
		Vectore C2=new Vectore(n,Vectore.TYPE_VECTOR.ROW);
		for (int i = 0; i < m ; i++) {
			for (int j = 0; j < n ; j++) {
				//if(i == 0) C2.setBigCell(j,ZERO_BIG);
				C2.setBigCell(j,C2.getBigCell(j)+ A.getCell(i, j))	;
			}
		}   
		return C2;
	}
	
	
	private Matrixe createTablePhase1() {
		
		Vectore C2=calcNewCoefficienti();
		double z_init= calcNewValueZ();
			
		Matrixe table = new Matrixe(m+1,n +m +1);
		basis = new int[m];
		
		//MATRICE ORIGINALE
		for (int i = 0; i < m ; i++) {
			for (int j = 0; j < n ; j++) {
				table.setCell(i,j,A.getCell(i, j));
			}
		}    
		//VARIABILI SLACKS - B - BASE 
		for (int i = 0; i < m ; i++) {
			table.setCell(i,n + i,1.0);
			table.setCell(i,m + n,  B.getBigCell(i)); //new 
			setBases(i,n+i); 
		}
		
		for (int j = 0; j < n ; j++) {
			table.setCell(m ,j,  C2.getBigCell(j));
		}
		
		table.setCell(m ,m+n,z_init);
		return table;
	}
	

	public Matrixe getTableExtended() {
		return this.table_exended;
	}


	public SolutionType resolve(long num_iteration)  {
		
		long LOCAL_NUM_MAX_ITERATION=num_iteration;
		int var_incoming=0,row_var_outgoing=0;
		SolutionType solution=SolutionType.MAX_ITERATIUM; 
		
		for(  ;this.iteration < LOCAL_NUM_MAX_ITERATION;  this.iteration++) {
			
			if(isBaseDegenerate())  var_incoming = test_var_incoming_bland();
			else var_incoming = test_var_incoming();
			
			if (var_incoming == -1) {	
				solution= SolutionType.OPTIMUM; 
				break;
			} 
			
			if ((row_var_outgoing = test_var_outgoing(var_incoming)) == -1) { 
				solution= SolutionType.ILLIMITATUM;
				break;
			}

			pivoting(row_var_outgoing,var_incoming);
			setBases(row_var_outgoing,var_incoming);
			
			//printTable();
			//printBases();
		}
		
		if(solution== SolutionType.MAX_ITERATIUM) logger.log(SscLevel.WARNING,"Raggiunto il massimo numero di iterazioni "+(LOCAL_NUM_MAX_ITERATION));
		double z=getValueZ();
		if(!isMilp) {
			logger.log(SscLevel.INFO,RB.getString("it.ssc.pl.milp.Phase1.msg1")+z);
			
		}
		
		
		if(solution== SolutionType.OPTIMUM && (   Math.abs(z) > cepsilon.getValue() )) {
			if(!isMilp)  {
				logger.log(SscLevel.NOTE,"Fase Uno - Condizione per esistenza di soluzioni ammissibili : |z| <= epsilon ="+cepsilon.getValue());
				logger.log(SscLevel.WARNING,"Fase Uno - Non sussuste la condizione per esistenza di soluzioni ammissibili in quanto |z| > epsilon . Il valore epsilon puo' essere modificato tramite il metodo setCEpsilon()");
			}
			return SolutionType.VUOTUM;
		}
		else return solution;
	}
	
	public void pulish() {
		//se c'e' una variabile ausiliaria in base (naturalmente degenere) si fa uscire 
		//se quelle presenti hanno zero sulle variabili reali.  Si tolgono le righe 
		// si cancellano le colonne relative alle ausiliaria  
		exitAuxFromBase();
		Matrixe table_pulish=deleteRowAux(table_exended);
		this.table_exended_pulish=deleteColumnAux(table_pulish);

	}
   
   public Matrixe getTablePulishClone() throws CloneNotSupportedException {
	   if(this.table_exended_pulish!=null) return  this.table_exended_pulish.clone();
	   else return null;
   }
   
   private Matrixe deleteRowAux(Matrixe table_pulish) {
	   
		int index_aux_out = 0;
		while (((index_aux_out = existAuxBase()) != -1) && ifAllCoeffZeroAux(index_aux_out)) {
			table_pulish=deleteSingleRowAux(index_aux_out,table_pulish);
			updateBase(index_aux_out);
		}
	    return table_pulish;
   }
   
   
   private void updateBase(int row_canc ) {
	   int new_basis[]=new int[basis.length-1];
	   int index_row = 0;
	   for (int i = 0; i < basis.length; i++) {
		   if (row_canc==i) continue;
		   new_basis[index_row]=basis[i] ;
		   index_row++;
	   }
	   basis=new_basis;
   }
   
   private Matrixe deleteSingleRowAux(int row_canc , Matrixe table_pulish) {
		int n_row = table_pulish.getNrow();
		Matrixe table = new Matrixe(n_row-1, n +m+ 1);

		int index_row = 0;
		for (int i = 0; i < n_row; i++) {
			if (row_canc==i) continue;
			
			for (int j = 0; j <= n + m; j++) {
				table.setCell(index_row, j, table_pulish.getCell(i, j));
			}
			index_row++;
		}
		return table;
	   
   }
   
   private boolean ifAllCoeffZeroAux(int index) {
	   for (int j = 0; j < n ; j++) {
		   //if(new BigDecimal(table_exended.getCell(index,j)).setScale(SCALE, RoundingMode.HALF_DOWN).doubleValue()  != 0.0) {
		   if( Math.abs(table_exended.getCell(index,j)) > epsilon.getValue()  ) {
			   return false;
		   }
	   }
	   return true;
   }
   
   //non tocca numero righe o colonne
   private void exitAuxFromBase() {
	   int index_aux_out = 0, index_orig_in = 0;
	   while (((index_aux_out = existAuxBase()) != -1) && ((index_orig_in = existVarOrigOutBase(index_aux_out)) != -1)) {
		   pivoting(index_aux_out, index_orig_in);
		   setBases(index_aux_out,index_orig_in);
	   }
   }

   private int existVarOrigOutBase(int index_aux) {
	   for (int j = 0; j < n ; j++) {
		   //if (!(new BigDecimal(table_exended.getCell(index_aux,j)).setScale(SCALE, RoundingMode.HALF_DOWN).doubleValue() == 0))  {
		   if ( Math.abs(table_exended.getCell(index_aux,j)) > epsilon.getValue() )  {
			   return j;
		   }
	   }
	   return -1;
   }
   
   private int existAuxBase() {
	   for (int i = 0; i < basis.length; i++) {
			if(basis[i] >= n) return i ;
		}
	   return -1;
   }
   
   
   private Matrixe deleteColumnAux(Matrixe A_all_col) {
	   int n_row = A_all_col.getNrow();
	   Matrixe table = new Matrixe(n_row, n + 1);

	   for (int i = 0; i < n_row; i++) {
		   int index_col = 0;
		   for (int j = 0; j <= n + m; j++) {
			   if (!(j < n || j == n + m)) continue;
			   table.setCell(i, index_col, A_all_col.getCell(i, j));
			   index_col++;
		   }
	   }
	   return table;
   }

}
