package it.ssc.pl.milp;

import it.ssc.log.SscLogger;

import java.util.logging.Level;
import java.util.logging.Logger;

 class ObjectiveFunctionImpl implements Cloneable, ObjectiveFunction {
	
	private static final Logger logger=SscLogger.getLogger();
	
	
	private Double[] C;
	private TARGET_FO type= TARGET_FO.MAX;
	
	public ObjectiveFunctionImpl(int dimension) {
		C=new Double[dimension];
	}
	
	public void setCj(int j, Double cj) {
		//System.out.println("VALUE Cj "+cj);
		C[j]=cj;
	}
	
	public Double getCj(int j) {
		return C[j];
	}
	
	
	public TARGET_FO getType() {
		return type;
	}
	public void setType(TARGET_FO type) {
		this.type = type;
	}
	
	
	public void standardize() {
		if(this.type==TARGET_FO.MIN) {
			this.type=TARGET_FO.MAX;
			for(int j=0;j<C.length;j++) {
				if(C[j]!=null && C[j]!=0) C[j]=-C[j];
			}
		}
	}
	
	
	public ObjectiveFunctionImpl clone() {
		
		ObjectiveFunctionImpl clone=null;
		try {
			clone=(ObjectiveFunctionImpl)super.clone();
			clone.C=(Double[])C.clone();
		} 
		catch (CloneNotSupportedException e) {
			logger.log(Level.SEVERE,"Clonazione it.ssc.pl.milp.ObjFunction",e);
		}
		return clone;
	}
}
