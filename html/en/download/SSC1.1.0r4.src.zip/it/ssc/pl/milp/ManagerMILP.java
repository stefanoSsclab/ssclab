package it.ssc.pl.milp;


import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import it.ssc.context.Session;
import it.ssc.context.exception.InvalidSessionException;
import it.ssc.datasource.DataSource;
import it.ssc.log.SscLogger;
import it.ssc.pl.milp.Variable.TYPE_VAR;
import it.ssc.ref.Input;
import it.ssc.vector_spaces.MatrixException;

 class ManagerMILP implements Cloneable {
	
	public enum VERSUS_SEPARATION { MINOR , MAJOR , ZERO , INTERVAL};
	
	private static final Logger logger=SscLogger.getLogger();
	private volatile static int  static_counter=1; 
	private int id;
	private MilpProblem milp_original;
	private static MilpProblem milp_original_zero;
	private SolutionImpl solution_pl;
	private int num_iteration;
	private final boolean isMilp=true;
	private EPSILON epsilon;
	private EPSILON iepsilon; 
	private EPSILON cepsilon;
	
	
	
public ManagerMILP(InputSparse input_sparse,Session session) throws InvalidSessionException, Exception {
		
		id=createId();  
		DataSource milp_data_source=session.createDataSource(input_sparse.getInput());
		milp_original=CreateMilpProblem.createFromSparse(milp_data_source,isMilp);
		milp_original.configureInteger();
		milp_original.configureSemicont();
	}
	
	public ManagerMILP(LinearObjectiveFunction f,ArrayList<Constraint> constraints) throws InvalidSessionException, Exception {
		id=createId(); 
		milp_original=CreateMilpProblem.create(f,constraints,isMilp);
		milp_original.configureInteger();
		milp_original.configureSemicont();
	}
	
	public ManagerMILP(Input milp_input,Session session) throws InvalidSessionException, Exception {
		
		id=createId(); 
		DataSource milp_data_source=session.createDataSource(milp_input);
		milp_original=CreateMilpProblem.create(milp_data_source,isMilp);
		milp_original.configureInteger();
		milp_original.configureSemicont();
	}
	
	public void setEpsilon(EPSILON epsilon) {
		this.epsilon=epsilon;
	}
	
	public void setIEpsilon(EPSILON epsilon) {
		this.iepsilon=epsilon; 
	}
	
	public void setCEpsilon(EPSILON epsilon) {
		this.cepsilon=epsilon; 
	}
	
	public void setMaxIteration(int num_iteration) throws SimplexException  {
		this.num_iteration=num_iteration;
	}
	
	public SolutionType resolve() throws SimplexException, MatrixException, CloneNotSupportedException, LPException {
		
		MilpProblem milp_standard=milp_original.clone();
		if(milp_original_zero==null) milp_original_zero=milp_original.clone();
		milp_standard.standardize(); 
		
		double[][] A=milp_standard.getMatrixA();
		double[]   B=milp_standard.getVectorB();
		double[]   C=milp_standard.getVectorC();
		
		SimplexInterface simplex=new Simplex(A, B, C,epsilon,cepsilon);
		simplex.setNumIterationMax(num_iteration);
		simplex.setMilp(true);
		
		SolutionType solution=simplex.phaseOne();
		if(solution==SolutionType.OPTIMUM) { 
			solution =simplex.phaseTwo();
			this.solution_pl=new SolutionImpl(solution,
											  milp_original_zero.clone(),
											  simplex.getFinalBasisClone(),
											  simplex.getFinalValuesBasisClone()
											  );
		}	
		
		return solution;
	}
	
	public double getOptimumValue() {
		 return solution_pl.getOptimumValue();
	}
	
	
	public ManagerMILP getCloneBySeparationContinus(int index_var,VERSUS_SEPARATION versus) throws CloneNotSupportedException, LPException {
		
		int num_tot_var= this.solution_pl.getVariables().length;
		ManagerMILP clone_separation=clone();
		Var variable=clone_separation.milp_original.getVariables()[index_var];
		variable.setSemicon(false);
		if(versus==VERSUS_SEPARATION.ZERO)  {
			//System.out.println(index_var+":ZERO-ZERO"+"   ID_CLONE"+clone_separation.getId() );
			InternalConstraint constraint=InternalConstraint.createConstraintFromVar( 
											num_tot_var, index_var, 0.0, InternalConstraint.TYPE_CONSTR.LE);
			clone_separation.milp_original.addConstraint(constraint);
		}
		else {
			variable.setUpper(variable.getUpperSemicon());
			variable.setLower(variable.getLowerSemicon());
		}

		return clone_separation;
	}
	
	
	public ManagerMILP getCloneBySeparation(int index_var,VERSUS_SEPARATION versus) throws CloneNotSupportedException {
		double value=this.solution_pl.getVariables()[index_var].getValue();
		int num_tot_var= this.solution_pl.getVariables().length;
		ManagerMILP clone_separation=clone();
		
		InternalConstraint constraint=null;
		if(versus==VERSUS_SEPARATION.MINOR)  {
			value=Math.floor(value);
			//System.out.println(index_var+":MINOR"+value +"   ID_CLONE"+clone_separation.getId() );
			constraint=InternalConstraint.createConstraintFromVar( 
					num_tot_var, index_var, value, InternalConstraint.TYPE_CONSTR.LE);
		}
		else {
			value=Math.ceil(value);
			//System.out.println(index_var+":MAIOR"+value+"   ID_CLONE"+clone_separation.getId());
			constraint=InternalConstraint.createConstraintFromVar(
					num_tot_var, index_var, value, InternalConstraint.TYPE_CONSTR.GE);
			
		}
		clone_separation.milp_original.addConstraint(constraint);
		return clone_separation;
	}
	
	public int getIndexVarToBeSemiContinus() {
		int index =0;
		Var[] variables= this.milp_original.getVariables();
		for(Var variable:variables) {
			if(variable.isSemicon() ) {
				return index;
			}
			index++;
		}
		return -1;
	}
	
	
	
	
	
	public int getIndexVarToBeInteger() {
		int index =0;
		Var[] variables= this.solution_pl.getVariables();
		for(Var variable:variables) {
			if(variable.getType()== TYPE_VAR.BINARY || variable.getType()== TYPE_VAR.INTEGER ) {
				double value=variable.getValue();
				if(!isInteger(value)) {
					return index;
				}
			}
			index++;
		}
		return -1;
	}
	
	
	public int getIndexVarToBeIntegerNew2() {
		int index =0;
		int index_bono=-1;
		double fraction=0.0;
		Var[] variables= this.solution_pl.getVariables();
		for(Var variable:variables) {
			if(variable.getType()== TYPE_VAR.BINARY || variable.getType()== TYPE_VAR.INTEGER ) {
				double value=variable.getValue();
				if(!isInteger(value)) {
					if(index_bono==-1) {
						index_bono= index;
						fraction= value % 1;
					}
					else if(fraction < (value % 1)) {
						index_bono= index;
						fraction= value % 1;
					}
				}
			}
			index++;
		}
		return index_bono;
	}
	
	
	
	
	public  boolean isProblemSemiContinusAmmisible()  {
		boolean is_continus_ammisible=true;
		Var[] variables= this.milp_original.getVariables();
		for(Var variable:variables) {
			if(variable.isSemicon()) is_continus_ammisible=false;
		}
		return is_continus_ammisible;
	}
	
	
	
	public boolean isSolutionIntegerAmmisible()  {
		boolean is_integer_ammisible=true;
		Var[] variables= this.solution_pl.getVariables();
		for(Var variable:variables) {
			if(variable.getType()== TYPE_VAR.BINARY || variable.getType()== TYPE_VAR.INTEGER ) {
				double value =variable.getValue();
				//if(true) value=new BigDecimal(value).setScale(Phase1.SCALE, RoundingMode.HALF_DOWN).doubleValue();
				if(!isInteger(value)) { 
					is_integer_ammisible=false;
				}
			}
		}
		return is_integer_ammisible;
	}
	
	public void setIntegerIfOptimal() {
		
		Var[] variables= this.solution_pl.getVariables();
		for(Var variable:variables) {
			if(variable.getType()== TYPE_VAR.BINARY || variable.getType()== TYPE_VAR.INTEGER ) {
				double value =variable.getValue();
				value=Math.rint(value);
				variable.setValue(value);
			}
		}
	}
	
	/*
	private static boolean isIntegerOld(double d) { 
		  return  !Double.isInfinite(d) && (d == Math.floor(d)) ;
	}
	*/
	
	private  boolean isInteger(double d) { 
		  // Note that Double.NaN is not equal to anything, even itself.
		  return  !Double.isInfinite(d) && 
		          ( Math.abs(d - Math.rint(d))  <= iepsilon.getValue()  ) ;
	}
	
	
	public Solution getSolution()  {
		return this.solution_pl;
	}
	
	
	public int  getId() {
		return id;
	}
	
	private static synchronized  int createId() {
		return static_counter++;
	}
	
	protected ManagerMILP clone() throws CloneNotSupportedException {
		ManagerMILP milp_clone=null;
		try {
			milp_clone = (ManagerMILP)super.clone();
			milp_clone.milp_original=this.milp_original.clone();
			milp_clone.solution_pl=null;
			milp_clone.id=ManagerMILP.createId();
			//System.out.println("GENERATO ID_CLONE:"+milp_clone.id);
		} 
		catch (CloneNotSupportedException e) {
			logger.log(Level.SEVERE,"Clonazione it.ssc.pl.milp.ManagerMILP",e);
			throw e;
		}
		return milp_clone;
	}
}

