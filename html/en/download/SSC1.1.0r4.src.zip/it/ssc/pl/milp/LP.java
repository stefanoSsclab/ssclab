

package it.ssc.pl.milp;

import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import it.ssc.context.Context;
import it.ssc.context.Session;
import it.ssc.datasource.DataSource;
import it.ssc.i18n.RB;
import it.ssc.log.SscLevel;
import it.ssc.log.SscLogger;
import it.ssc.ref.Input;



/**
 * Questa classe permette di eseguire e risolvere formulazioni di problemi di programmazione 
 * lineare. Il metodo utilizzato per la risoluzione di tali problemi di ottimizzazione &egrave; il 
 * metodo del simplesso
 * 
 * @author Stefano Scarioli
 * @version 1.0
 * @see <a target="_new" href="http://www.ssclab.org">SSC Software www.sscLab.org</a>
 */

public class LP {
	
	private static final Logger logger=SscLogger.getLogger();
	
	private MilpProblem milp_original;
	private SolutionImpl solution_pl;
	private int num_max_iteration=100000;
	private double[][] A;
	private double[]   B;
	private double[]   C;
	private Session session;
	private final boolean isMilp=false;
	private EPSILON epsilon=EPSILON._1E_M10;
	private EPSILON cepsilon=EPSILON._1E_M8;
	
	
	/**
	 * Costruttore di un oggetto LP per la risoluzione di problemi formulati in formato a disequazioni contenute in stringhe. 
	 * In questo formato le variabili devono necessariamente chiamarsi X<sub>j</sub>, con l'indice j che parte da 1. 
	 * 
	 * @param inequality  Lista dei vincoli di tipo (EQ,GE,LE) sotto forma di disequazioni contenute in stringhe
	 * @param fo Un oggetto LinearObjectiveFunction che rappresenta la funzione obiettivo
	 * @throws Exception Viene generata una eccezione se il problema non &egrave; formulato correttamente 
	 */
	
	public LP(ArrayList<String> inequality,LinearObjectiveFunction fo) throws Exception  { 
		
		int dimension=fo.getC().length;
		ConstraintFromString cfs=new ConstraintFromString(dimension, inequality);
		ArrayList<Constraint> new_constraints=cfs.getConstraint();
		
		milp_original=CreateMilpProblem.create(fo,new_constraints,isMilp);
		createStandartProblem();
	}
	
	/**
	 * Costruttore di un oggetto LP per la risoluzione di problemi formulati in formato a disequazioni contenute in stringhe. 
	 * In questo formato le variabili devono necessariamente chiamarsi X<sub>j</sub>, con l'indice j che parte da 1. Il terzo parametro 
	 * &egrave; la lista dei vincoli che non sono di tipo EQ,LE,GE, ma UPPER e LOWER e vanno rappresentati come oggetti Constraint. 
	 * 
	 * @param inequality Lista dei vincoli di tipo EQ,GE,LE sotto forma di disequazioni contenute in stringhe
	 * @param constraints Lista dei vincoli di tipo UPPER e LOWER rappresentati come oggetti Constraint
	 * @param fo  Un oggetto LinearObjectiveFunction che rappresenta la funzione obiettivo
	 * @throws Exception  Viene generata una eccezione se il problema non &egrave; formulato correttamente
	 */
	
	public LP(ArrayList<String> inequality,ArrayList<Constraint> constraints,LinearObjectiveFunction fo) throws Exception  { 
		int dimension=fo.getC().length;
		ConstraintFromString cfs=new ConstraintFromString(dimension, inequality,constraints);
		ArrayList<Constraint> new_constraints=cfs.getConstraint();
		milp_original=CreateMilpProblem.create(fo,new_constraints,isMilp);
		createStandartProblem();
	}
	
	
	/**
	 * Costruttore di un oggetto LP per la risoluzione di problemi formulati in formato a disequazioni contenute in stringhe. 
	 * In questo formato le variabili devono necessariamente chiamarsi X<sub>j</sub>, con l'indice j che parte da 1. Il terzo parametro 
	 * &egrave; la lista dei vincoli che non sono di tipo EQ,LE,GE, ma UPPER e LOWER e vanno rappresentati come oggetti Constraint. 
	 *  
	 * @param inequality
	 * @param constraints
	 * @param fo
	 * @throws Exception
	 */
	
	
	public LP(ArrayList<String> inequality,ListConstraints constraints,LinearObjectiveFunction fo) throws Exception  { 
		int dimension=fo.getC().length;
		ConstraintFromString cfs=new ConstraintFromString(dimension, inequality,constraints.getListConstraint());
		ArrayList<Constraint> new_constraints=cfs.getConstraint(); 
		milp_original=CreateMilpProblem.create(fo,new_constraints,isMilp);
		createStandartProblem();
	}
	
	
	
	/**
	 * Costruttore di un oggetto LP per la risoluzione di problemi espressi in formato matriciale.
	 * 
	 * @param fo Un oggetto LinearObjectiveFunction che rappresenta la funzione obiettivo
	 * @param constraints La lista dei vincoli 
	 * @throws Exception Viene generata una eccezione se il problema non &egrave; formulato correttamente 
	 * 
	 */

		
	public LP(LinearObjectiveFunction fo,ArrayList<Constraint> constraints) throws Exception  { 
		milp_original=CreateMilpProblem.create(fo,constraints,isMilp);
		createStandartProblem();
	}
	
	
	/**
	 * Costruttore di un oggetto LP per la risoluzione di problemi espressi in formato matriciale.
	 * 
	 * @param fo Un oggetto LinearObjectiveFunction che rappresenta la funzione obiettivo
	 * @param constraints La lista dei vincoli 
	 * @throws Exception Viene generata una eccezione se il problema non &egrave; formulato correttamente 
	 * 
	 */
	
	public LP(LinearObjectiveFunction fo,ListConstraints constraints) throws Exception  { 
		milp_original=CreateMilpProblem.create(fo,constraints.getListConstraint(),isMilp);
		createStandartProblem();
	}
	
	
	
	/**
	 * Questo metodo permette di settare il valore epsilon relativo alla tolleranza che interviene in diversi ambiti. &Egrave;  
	 * utilizzato nei seguenti casi : <br>
	 * 
	 * 1) Durante la fase uno, sia nella determinazione delle variabile entrante che in quella della variabile uscente con o senza regola di Bland. 
	 *    Sia per determinare se la base &egrave; degenere. Viene anche utilizzata alla fine della fase uno : se esiste una variabile ausiliaria in base, 
	 *    epsilon viene utilizzato per determinare se &egrave; possibile eliminare le righe e le colonne di queste sulla tabella estesa.  <br>
	 * 2) Durante la fase due , sia nella determinazione delle variabile entrante che in quella della variabile uscente con o senza regola di BLand. 
	 *    Sia per determinare se la base &egrave; degenere.   
	 * 
	 * @param epsilon Toleranza utilizzata in diverse fasi del simplesso. Valore default 1-E10
	 */
	
	
	public void setEpsilon(EPSILON epsilon)   {  
		this.epsilon=epsilon;
	}
	
	/**
	 * Questo metodo permette di settare il valore epsilon relativo alla tolleranza per 
	 * determinare se una soluzione ottima della fase 1 del simplesso &egrave; prossima o uguale a zero e quindi da origine a 
	 * soluzioni ammissibili per il problema iniziale. 
	 * 
	 * @param epsilon Tolleranza soluzione fase 1 rispetto allo zero. Valore default 1-E8
	 */
	
	public void setCEpsilon(EPSILON epsilon)  { 
		this.cepsilon=epsilon;
	}
	
	/**
	 *  Costruttore di un oggetto LP per la risoluzione di problemi espressi in formato sparso.
	 * 
	 * @param input_sparse Il problema formulato col formato sparso 
	 * @param session Una sessione di lavoro SSC 
	 * @throws Exception Viene generata una eccezione se il problema &egrave; formulato in modo non corretto
	 */
	
	public LP(InputSparse input_sparse,Session session) throws Exception {
		this.session=session;
		DataSource milp_data_source=session.createDataSource(input_sparse.getInput());
		milp_original=CreateMilpProblem.createFromSparse(milp_data_source,isMilp);
		createStandartProblem();
	}
	
	/**
	 * Costruttore di un oggetto LP per la risoluzione di problemi espressi in formato sparso.
	 * 
	 * @param input_sparse Il problema formulato col formato sparso
	 * @throws Exception Viene generata una eccezione se il problema &egrave; formulato in modo non corretto
	 */
	
	public LP(InputSparse input_sparse) throws  Exception {
		
		this(input_sparse, Context.createNewSession());
		logger.log(Level.INFO,RB.getString("it.ssc.pl.milp.LP.msg1")); 
		session.close();
	}
	
	/**
	 * Costruttore di un oggetto LP per la risoluzione di problemi espressi in formato naturale.
	 * 
	 * @param input_natural Il problema formulato col formato naturale
	 * @throws Exception Viene generata una eccezione se il problema &egrave; formulato in modo non corretto
	 */

	public LP(Input input_natural) throws Exception {
		
		this(input_natural, Context.createNewSession());
		logger.log(Level.INFO,RB.getString("it.ssc.pl.milp.LP.msg1")); 
		session.close();
	}
	
	/**
	 * Costruttore di un oggetto LP per la risoluzione di problemi espressi in formato naturale.
	 * 
	 * @param input_natural Il problema formulato col formato naturale
	 * @param session Una sessione di lavoro SSC 
	 * @throws Exception Viene generata una eccezione se il problema &egrave; formulato in modo non corretto
	 */
	
	public LP(Input input_natural,Session session) throws Exception {
		
		this.session=session;
		DataSource milp_data_source=session.createDataSource(input_natural);
		milp_original=CreateMilpProblem.create(milp_data_source, isMilp);
		createStandartProblem(); 
	}
	
	/**
	 * Questo metodo permette di limitare il numero massimo di iterazioni del simplesso (iterazioni fase 1 + iterazioni fase 2)
	 * 
	 * @param num_max_iteration Il numero di iterazioni che al massimo si vuole far eseguire. Valore di default 100000. 
	 * @throws LPException Se si imposta un numero errato (negativo) 
	 */
	public void setNumMaxIteration(int num_max_iteration) throws LPException  { 
		if(num_max_iteration <= 0) throw new LPException("Il numero massimo di iterazioni deve essere un numero positivo");
		this.num_max_iteration=num_max_iteration;
	}
	
	/**
	 * Questo metodo ritorna il numero massimo di iterazioni del simplesso
	 * 
	 * @return Il numero massimo i iterazioni
	 */
	
	public int getNumMaxIteration()   { 
		return this.num_max_iteration;
	}
	
	/**
	 * Esegue il simplesso (fase 1 + fase 2).
	 * 
	 * @return Il tipo di soluzione trovata 
	 * @throws Exception Se il processo di esecuzione genera un errore 
	 */
	
	public SolutionType resolve() throws Exception {
		SimplexInterface simplex = null;
		simplex=new Simplex(A, B, C,epsilon,cepsilon);
		simplex.setNumIterationMax(num_max_iteration);
		
		long start=System.currentTimeMillis();
		SolutionType type_solution=simplex.phaseOne();
		long end_phase_one=System.currentTimeMillis();
		long end_phase_two=end_phase_one;
		
		
		logger.log(SscLevel.TIME,RB.format("it.ssc.pl.milp.LP.msg2", (end_phase_one-start)));
		logger.log(SscLevel.INFO,RB.getString("it.ssc.pl.milp.LP.msg3")+simplex.getNumIterationPhaseOne());
		
		if(type_solution==SolutionType.OPTIMUM) {
			type_solution =simplex.phaseTwo();
			end_phase_two=System.currentTimeMillis(); 
			logger.log(SscLevel.TIME,RB.format("it.ssc.pl.milp.LP.msg4",(end_phase_two-end_phase_one)));
			logger.log(SscLevel.INFO,RB.getString("it.ssc.pl.milp.LP.msg5")+simplex.getNumIterationPhaseTotal());
			this.solution_pl=new SolutionImpl(type_solution,
											  milp_original.clone(),
											  simplex.getFinalBasisClone(),
											  simplex.getFinalValuesBasisClone()
											 );
			
		}	
		logger.log(SscLevel.TIME,RB.format("it.ssc.pl.milp.LP.msg6",(end_phase_two-start)));
		if(type_solution==SolutionType.OPTIMUM) logger.log(SscLevel.INFO,RB.getString("it.ssc.pl.milp.LP.msg7"));
		return type_solution;

	}
	
	/**
	 * Questo metodo ritorna la matrice A ottenuta in seguito al processo di riduzione in 
	 * forma standart del problema di programmazione lineare di partenza.
	 * 
	 * @return La matrice dei coefficienti A 
	 */
	public double[][] getStandartMatrixA() {
		return A.clone();
	}

	/**
	 * Questo metodo ritorna il vettore b dei valori rhs ottenuto in seguito al processo di riduzione in 
	 * forma standart del problema di programmazione lineare di partenza.
	 * 
	 * @return Il vettore dei coefficienti RHS 
	 */
	
	public double[] getStandartVectorB() {
		return B.clone();
	}

	/**
	 * Questo metodo ritorna il vettore c dei coefficienti della f.o. in seguito al processo di riduzione 
	 * in forma standart del problema di programmazione lineare di partenza.
	 * 
	 * @return Il vettore c dei coefficienti della f.o.
	 */
	public double[] getStandartVectorC() {
		return C.clone();
	}

	/**
	 * Se il problema ammette soluzione ottima , questo metodo ritorna tale soluzione ottima sotto forma di oggetto della 
	 * classe Solution
	 * @return La soluzione ottima del problema 
	 * @throws SimplexException Se la soluzione ottima non &egrave; presente 
	 */
	
	public Solution getSolution() throws SimplexException  {
		if(this.solution_pl==null)  throw new SimplexException("Non e' presente nessuna soluzione ottima del problema");
		return this.solution_pl;
	}
	
	
	private void createStandartProblem() {
		
		MilpProblem milp_standard=milp_original.clone(); 
		milp_standard.standardize(); 
		
		A=milp_standard.getMatrixA();
		B=milp_standard.getVectorB();
		C=milp_standard.getVectorC();
		
	}
}
