package it.ssc.library.exception;

public class RenameDatasetException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public RenameDatasetException(String message) {
		super(message);
	}

}
