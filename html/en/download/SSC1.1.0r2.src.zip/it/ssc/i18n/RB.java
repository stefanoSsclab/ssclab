package it.ssc.i18n;

import java.text.MessageFormat;
import java.util.ResourceBundle;

public class RB {
	public static  ResourceBundle msg; 
	
	
	static { 
		msg= ResourceBundle.getBundle(RB.class.getPackage().getName()+".MessagesBundle");
	}
	
	public static void main(String arg[]) {
		System.out.println(RB.getString("it.ssc.library.library.DbLibrary.msg1"));
	}
	
	public static String getString(String key) {
		return msg.getString(key);
	}
	
	public static String format(String key, Object... arguments) {
		return MessageFormat.format(RB.getString(key),arguments);
	}
}
