package it.ssc.step.exception;

public class InvalidDichiarationOptions extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidDichiarationOptions(String message) {
		super(message);
	}

}
