package it.ssc.step.sort.exception;

public class SortException 	extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

		public SortException(String message) {
			super(message);
	}
}
