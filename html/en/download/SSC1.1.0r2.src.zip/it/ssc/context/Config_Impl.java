package it.ssc.context;


public class Config_Impl  implements Config {
	
	//Fare in modo che possa gestire le versioni
	//PENSARCI BENE
	
	public static final String NAME_DIR_COMPILER="compiler";
	public static final String NAME_DIR_SORTING="sorting";
	
	
	public static final String NAME_DIR_WORK="ssc_work";
	
	public static final String ESTENSION_FILE_FMT = ".sscdati";
	public static final String ESTENSION_META_FMT = ".sscmeta";
	public static final String ESTENSION_COPY_TEMP_FMT = ".copytmp";
	public static final String TOKEN_MISSING = ".";
	public static final String NL = System.getProperty("line.separator");
	

	private String path_root_library_work=System.getProperty("user.dir");
	
	Config_Impl() {
		//deve leggere il file di configurazione di default e caricare le informazioni
		
	}
	
	Config_Impl(String path_file_config) {
		//deve leggere il file di configurazione specificato nel path e caricare le informazioni
	}
	/**
	 * Ritorna la directory di work contenitrice di tutte le directory di work create 
	 * con nomi randomici relative alle diverse sessioni fmt 
	 */
	public String getPathWorkArea()  {
		return path_root_library_work;
	}
	
	public void setPathWorkArea(String path_work) {
		this.path_root_library_work=path_work;
	}
}
