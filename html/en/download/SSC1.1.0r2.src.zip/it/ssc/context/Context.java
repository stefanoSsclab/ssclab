package it.ssc.context;


import it.ssc.context.exception.InvalidSessionException;
import it.ssc.io.DirectoryNotFound;
import it.ssc.library.exception.InvalidLibraryException;


/**
 * Questa classe permette di accedere al constesto (ambiente di esecuzione) del sistema SSC. <br>
 * 
 * Nel particolare, attraverso il Contesto  si generano principalmente le sessioni 
 * di lavoro SSC. Partendo da una sessione di lavoro SSC si possono effettuare diverse operazione : 
 * allocazione di librerie, creazione di un'area  di  work, attivazione di  
 * eventuali connessioni a database esterni (viste come librerie), manipolazione ed elaborazione dei dati.<br>
 * Tutte queste risorse esterne (librerie di dati o DB esterni), una volta referenziate in una sessione di lavoro, 
 * sono sempre e solo riconducibili alla singola sessione di lavoro che le ha allocate. 
 * Alcune proprieta' di ogni sessione di lavoro sono impostate configurando il file config.xml. 
 * In questo file di configurazione possono essere preallocate delle librerie, effettuate connessioni al db, 
 * definito il path dell'area di work, etc. 
 * <br/><br/>
 * <font color="red">
 * Nel file config.xml mettere un tag per la gestione della versione <version >  o 
 * come attributo <config version="1.2"> . Il file config.xml deve soddisfare un DTD o 
 * uno schema. 
 * </font>
 * 
 * 
 * @author Stefano Scarioli
 * @version 1.0
 */

public class Context {
	
	private Context() {
		
	}
	
	/**
	 * E' l'oggetto che ha la responsabilita' della gestione delle diverse sessioni
	 */
	private static SessionsManager session_manager;
	
	/**
	 * E' l'oggetto che contiene la corrente configurazione  utilizzata per le nuove sessioni.
	 * Inizialmente, se non modificata, e' la configurazione di default. 
	 */
	private static Config current_config;
	
	static {
		session_manager=new SessionsManager(); 
	}
	
	/**
	 * 
	 * Crea una sessione SSC partendo da un file di configurazione diverso 
	 * da quello di default. 
	 * 
	 * @param path_file_config  Path completo e nome del file di configurazione del tipo config.xml
	 * 
	 * @return Una nuova sessione SSC di lavoro
	 * @throws DirectoryNotFound
	 * @throws InvalidLibraryException
	 * @throws InvalidSessionException 
	 */
	

	public synchronized static Session createNewSession(String path_file_config) throws DirectoryNotFound, InvalidLibraryException, InvalidSessionException {
		Config config = new Config_Impl(path_file_config);
		return session_manager.getNewSession(config);
	}
	
	
	/**
	 * Crea una nuova sessione SSC partendo dalla configurazione di default. 
	 * 
	 * @return Una nuova  sessione SSC di lavoro
	 * @throws InvalidLibraryException 
	 * @throws DirectoryNotFound 
	 * @throws InvalidSessionException 
	 */

	public synchronized static Session createNewSession() throws DirectoryNotFound, InvalidLibraryException, InvalidSessionException {
		Config config = getContextConfig();
		return session_manager.getNewSession(config);
	} 
 
	/**
	 * Permette di recuperare una sessione SSC precedentemente creata tramite il suo ID.
	 * Se tale sessione non esiste ritorna null;
	 * 
	 * @param id della sessione 
	 * @return una sessione SSC con tale ID o null se tale sessione non esiste. 
	 * @throws InvalidSessionException 
	 */
	
	public synchronized static Session getSessionById(int id) throws InvalidSessionException {
		return session_manager.getSessionById(id);
	}
  
	

	/**
	 * Restituisce sempre il corrente Config di contesto. Se questo non e' stato modificato 
	 * risulta il config di default. 
	 * 
	 * @return l'oggetto Config corrente del contesto 
	 */
	
	public static Config getContextConfig() {
		if(current_config==null)  current_config = new Config_Impl();
		return current_config;
	}
	
	/**
	 * Setta il corrente Config di contesto. Se questo non era stato modificato 
	 * sostituisce il config di default con quello personalizzato. 
	 * 
	 * @return l'oggetto Config relativo al nuovo file di configurazione 
	 */
	
	public static Config setContextConfig(String path_file_config) {
		current_config = new Config_Impl(path_file_config);
		return current_config;
	}
}