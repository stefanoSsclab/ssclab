package it.ssc.context;

import it.ssc.context.exception.InvalidSessionException;
import it.ssc.io.DirectoryNotFound;

public interface Session_Priv extends Session {
	
	public Config getConfig() throws InvalidSessionException;
	public String getPathCompiler() throws InvalidSessionException, DirectoryNotFound;
	public String getPathSorting() throws InvalidSessionException, DirectoryNotFound;
	public void generateExceptionOfSessionClose() throws InvalidSessionException;

}
