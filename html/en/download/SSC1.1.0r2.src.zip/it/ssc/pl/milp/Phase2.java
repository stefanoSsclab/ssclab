package it.ssc.pl.milp;


import java.util.logging.Logger;
import it.ssc.log.SscLevel;
import it.ssc.log.SscLogger;
import it.ssc.vector_spaces.Matrixe;
import it.ssc.vector_spaces.Vectore;

/**
 * @author Scarioli
 */

 class Phase2 extends Phase {
	
	private final int n;
	private final int m;
	private static final Logger logger=SscLogger.getLogger();
	
	
	public Phase2(Matrixe phase1, int[] basis_p1, Vectore C1, long prec_num_iteration,EPSILON epsilon) 	throws SimplexException {
		
		super(phase1.getNrow()-1,phase1.getNcolumn()-1,epsilon);
		this.iteration=prec_num_iteration;
		this.m = phase1.getNrow() - 1;
		this.n = phase1.getNcolumn() - 1;

		if (C1.getTipo() == Vectore.TYPE_VECTOR.COLUMN) {
			C1.traspose();
		}
		
		this.basis = basis_p1;
		Vectore C = updateC(phase1,C1);
		updateZ(phase1,C1);
		
		this.table_exended = updateTableExtended(phase1,C); 
	}
	
	public SolutionType resolve(long num_iteration)  {
		
		//printTable();
		
		long LOCAL_NUM_ITERATION=num_iteration;
		int var_incoming=0,row_var_outgoing=0;
		
		for(;this.iteration < LOCAL_NUM_ITERATION;  this.iteration++) {
			
			if(isBaseDegenerate())  var_incoming = test_var_incoming_bland();
			else var_incoming = test_var_incoming();
			
			if (var_incoming == -1) {	
				return SolutionType.OPTIMUM; 
			} 
			
			if ((row_var_outgoing = test_var_outgoing(var_incoming)) == -1) { 
				return SolutionType.ILLIMITATUM;
			}

			pivoting(row_var_outgoing,var_incoming);
			setBases(row_var_outgoing,var_incoming);

		}
		
		logger.log(SscLevel.TIME,"Raggiunto il massimo numero di iterazioni "+(LOCAL_NUM_ITERATION));
		return SolutionType.MAX_ITERATIUM;
	}
	
	private void updateZ(Matrixe phase1,Vectore C)  {
		int dim_c=C.lenght();
		double somma_valori=0.0;
		for(int _j=0;_j<dim_c;_j++) {
			int row_bases=isIndexInBase(_j);
			if(row_bases > -1) {
				double value_c=C.getBigCell(_j);
				double value =phase1.getCell(row_bases, n) * value_c;
				somma_valori=somma_valori- value;
			}
		}
		phase1.setCell(m, n, somma_valori);
	}
	
	
	private Vectore updateC(Matrixe phase1,Vectore C1) {
		int dim_c=C1.lenght();
		Matrixe somma_valori_C=new Matrixe(dim_c,dim_c);
		for(int _j=0;_j<dim_c;_j++) {
			int row_bases=isIndexInBase(_j);
			double value_c=C1.getBigCell(_j);
			
			if(row_bases > -1) {
				if( !(value_c==0.0)) {           //ATTENZIONEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE
					for(int _k=0;_k<dim_c ;_k++) {
						if((isIndexInBase(_k) < 0)) {
							double value =phase1.getCell(row_bases, _k)* value_c;
							somma_valori_C.setCell(_j, _k,value*-1.0);
						}
					}
				}
			}
			//se non e' in base
			else {
				somma_valori_C.setCell(_j, _j, value_c);
			}
		}
		
		Vectore new_C=new Vectore(dim_c,Vectore.TYPE_VECTOR.ROW);  
		for(int _j=0;_j<dim_c;_j++) {
			for(int _k=0;_k<dim_c;_k++) {
				double value=new_C.getBigCell(_k);
				value=value + somma_valori_C.getCell(_j,_k);
				new_C.setBigCell(_k, value);
			}
		}
		return new_C;
	}
	
	private int  isIndexInBase(int index) {
		for (int i = 0; i < basis.length; i++) {
			if(index== basis[i]) {
				return i;
			}
		}
		return -1;
	}

	private Matrixe updateTableExtended(Matrixe phase1,Vectore C) {
		for (int j = 0; j < n; j++) {
			phase1.setCell(m, j, C.getBigCell(j));
		}
		return phase1;
	}

	public Matrixe getTableExtended() {
		return this.table_exended;
	}
	
	public double[] getValuesBases() {
		double[] values=new double[this.m];
		for(int _a=0;_a <this.m;_a++) {
			values[_a]= table_exended.getCell(_a, this.n);
			//System.out.println("VALUESSSE:"+values[_a]);
		}
		return values;
	}
}
