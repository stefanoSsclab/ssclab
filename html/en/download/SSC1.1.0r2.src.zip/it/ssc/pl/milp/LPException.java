package it.ssc.pl.milp;

/**
 * 
 * @author Stefano Scarioli 
 *
 */

public class LPException  extends Exception {
	
	private static final long serialVersionUID = 1L;

	public LPException(String message) {
		super(message);
}

}
