package it.ssc.pl.milp;

import it.ssc.i18n.RB;
import it.ssc.log.SscLogger;

import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;


 class MilpProblem implements Costant , Cloneable {
	 
	private static final Logger logger=SscLogger.getLogger();	
	private ObjectiveFunctionImpl fo;
	private ArrayList<InternalConstraint> list_constraint;  
	private Var[] array_var;
	private int new_dimension;
		
	public ObjectiveFunctionImpl getObjFunction() {
		return fo.clone();
	}

	public MilpProblem(int dimension) {
		list_constraint=new ArrayList<InternalConstraint>(); 
		initArrayVar(dimension);
		fo=new ObjectiveFunctionImpl(dimension);
	}
	
	private void initArrayVar(int dimension) {
		array_var=new Var[dimension] ;
		for(int _j=0;_j< array_var.length;_j++) {
			array_var[_j]=new Var(); 
		}
	}
	
	public void setNameVar(int index,String name_var) {
		array_var[index].setName(name_var);
	}
	
	public void setCjOF(int index, Double value) {
		fo.setCj(index, value);
	}
	
	public void setTargetObjFunction(String target) {
		if(target.equalsIgnoreCase(MIN)) fo.setType(ObjectiveFunctionImpl.TARGET_FO.MIN);
		else if(target.equalsIgnoreCase(MAX)) fo.setType(ObjectiveFunctionImpl.TARGET_FO.MAX);
	}
	
	public Var getVar(int index) {
		return array_var[index];
	}
	
	public Var[] getVariables() {
		return array_var; 
	}

	public void addConstraint(InternalConstraint constraint) {
		list_constraint.add(constraint);
	}
	
	public void standardize() {
		
		fo.standardize();
		
		//ciclo sulle variabili 
		//Se lower o upper != null -> vincoli 
		for(int _j=0;_j< array_var.length;_j++) {
			Double lower=array_var[_j].getLower();
			Double upper=array_var[_j].getUpper();
			if(lower!=null && lower!=0.0) {
				InternalConstraint constraint=InternalConstraint.createConstraintFromVar(
						array_var.length, _j, lower, InternalConstraint.TYPE_CONSTR.GE);
				list_constraint.add(constraint);
			}
			if(upper!=null) {
				InternalConstraint constraint=InternalConstraint.createConstraintFromVar(
						array_var.length, _j, upper, InternalConstraint.TYPE_CONSTR.LE);
				list_constraint.add(constraint);
			}
		}
		
		
		//da mettere alla fine 
		for(InternalConstraint constraint: list_constraint) {
			constraint.standardize();
		}
		
		/*
		for(Constraint constraint: list_constraint) {
			constraint.aprint();
		}
		*/
		
		this.new_dimension=newDimensionProblemToPhase1();
	}
	
	
	public double []  getVectorC() {
		double C[]=new double[new_dimension];
		int index_cj=0;
		for(int _a=0;_a<array_var.length;_a++) {
			Double cj=fo.getCj(_a);
			C[index_cj]=cj;
			index_cj++;
			if(array_var[_a].isFree()) {
				if(cj!=0.0) C[index_cj]=-cj;
				else C[index_cj]=0.0;
				index_cj++;
			}
		}
		return C;
	}
	
	public double[][]  getMatrixA() {
		double Aij[][]=new double[list_constraint.size()][new_dimension];
		int index_contr=0;
		int index_Ai=0;
		int index_slack=0;
		for(InternalConstraint constraint: list_constraint) {
			index_Ai=0;
			for(int _a=0;_a<array_var.length;_a++) { 
				double aij=constraint.getAij(_a);
				Aij[index_contr][index_Ai]=aij;
				index_Ai++;
				if(array_var[_a].isFree()) {
					if(aij!=0) Aij[index_contr][index_Ai]=-aij;
					else Aij[index_contr][index_Ai]=0.0;
					index_Ai++;
				}
			}
			
			if(index_slack==0) index_slack=index_Ai;
			if((constraint.getType()==InternalConstraint.TYPE_CONSTR.GE)) {
				Aij[index_contr][index_slack]=-1.0;
				index_slack++;
			}
			else if((constraint.getType()==InternalConstraint.TYPE_CONSTR.LE)) {
				Aij[index_contr][index_slack]=1.0;
				index_slack++;
			}
			
			index_contr++;
		}
		return Aij;
		
	}
	
	public double [] getVectorB() {
		double B[]=new double[list_constraint.size()];
		int index_b=0;
		for(InternalConstraint constraint: list_constraint) {
			B[index_b]=constraint.getBi();
			index_b++;
		}
		
		return B;
	}
	
	private int newDimensionProblemToPhase1() {
		int N=array_var.length;
		int N_free=0;
		int N_slacks=0;
		for(int _j=0;_j< array_var.length;_j++) {
			if(array_var[_j].isFree()) N_free++;
		}
		for(InternalConstraint constraint: list_constraint) {
			if(!(constraint.getType()==InternalConstraint.TYPE_CONSTR.EQ)) N_slacks++;
		}
		return N+N_free+N_slacks;
	}
	
	
	public MilpProblem clone() {
		
		MilpProblem clone=null;
		try {
			clone=(MilpProblem)super.clone();
			clone.array_var=array_var.clone();
			for(int _a=0;_a<clone.array_var.length;_a++) {
				clone.array_var[_a]=array_var[_a].clone();
			}
			
			clone.fo=fo.clone();
			clone.list_constraint=new ArrayList<InternalConstraint>();
			
			for(InternalConstraint constra: list_constraint) {
				clone.list_constraint.add(constra.clone());
			}
		} 
		catch (CloneNotSupportedException e) {
			logger.log(Level.SEVERE,"Clonazione it.ssc.pl.milp.MilpProblem",e);
		}
		return clone;
	}
	
	public void configureInteger() throws LPException {
		boolean is_present_upper_or_lower_in_var_binary=false; 
		for(Var var:array_var) {
			if(var.getType()==Var.TYPE_VAR.BINARY) {
				if(var.getLower()!=null && var.getLower()!= 0.0) {
					is_present_upper_or_lower_in_var_binary=true; 
				}
				else if(var.getUpper()!=null && var.getUpper()!= 1.0) {
					is_present_upper_or_lower_in_var_binary=true;
				}
				var.setUpper(1.0); //1.0
				var.setLower(0.0); //0.0
			}
			
			if(var.getType()==Var.TYPE_VAR.INTEGER) { 
				Double upper=var.getUpper();
				if(upper!=null) {
					upper=Math.floor(upper);
					var.setUpper(upper);
				}
				
				Double lower=var.getLower();
				if(lower!=null) {
					lower=Math.ceil(lower);
					var.setLower(lower);
				}
			}
		}
		if(is_present_upper_or_lower_in_var_binary) {
			logger.log(Level.WARNING,RB.getString("it.ssc.pl.milp.MilpProblem.msg1"));
		}
	}
	
	
	public void configureSemicont() throws LPException {
		
		for(Var var:array_var) {
			if(var.isSemicon()) { 
				Double upper=var.getUpper();
				Double lower=var.getLower();
				var.resetUpperLower();
				var.setUpperSemicon(upper);
				var.setLowerSemicon(lower);
				
				if((lower==null || lower <= 0.0) && (upper==null || upper >= 0.0)) {
					throw new LPException(RB.format("it.ssc.pl.milp.MilpProblem.msg2", var.getName()));
				}
			}
		}
			
	}
	
	

	public ArrayList<InternalConstraint> getListConstraint() {
		return list_constraint;
	}
}
