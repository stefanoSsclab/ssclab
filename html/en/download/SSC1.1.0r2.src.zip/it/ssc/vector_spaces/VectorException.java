package it.ssc.vector_spaces;

public class VectorException extends Exception {
	
	private static final long serialVersionUID = 1L;

	public VectorException(String massage) {
		super(massage);
	}


}
