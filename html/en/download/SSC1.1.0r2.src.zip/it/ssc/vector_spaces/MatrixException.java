package it.ssc.vector_spaces;

public class MatrixException extends Exception { 
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MatrixException(String massage) {
		super(massage);
	}

}
