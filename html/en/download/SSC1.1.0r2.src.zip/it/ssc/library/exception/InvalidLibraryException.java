package it.ssc.library.exception;

public class InvalidLibraryException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidLibraryException(String message) {
		super(message);
	}
}
