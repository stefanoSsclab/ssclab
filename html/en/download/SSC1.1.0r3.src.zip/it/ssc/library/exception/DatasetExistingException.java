package it.ssc.library.exception;

public class DatasetExistingException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public DatasetExistingException(String message) {
		super(message);
	}

}
