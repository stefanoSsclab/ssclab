package it.ssc.parser.exception;

public class InvalidStringForInputMissingException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidStringForInputMissingException(String massage) {
		super(massage);
		// TODO Auto-generated constructor stub
	}

}
