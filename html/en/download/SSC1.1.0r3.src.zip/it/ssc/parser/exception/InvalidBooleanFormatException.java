package it.ssc.parser.exception;

public class InvalidBooleanFormatException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidBooleanFormatException(String message) {
		super(message);
}
}
