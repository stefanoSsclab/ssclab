package it.ssc.parser.exception;

public class InvalidInformatStringException extends Exception  {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidInformatStringException(String massage) {
		super(massage);
		// TODO Auto-generated constructor stub
	}
}
