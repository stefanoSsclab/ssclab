package it.ssc.util;

import java.util.Arrays;
public class SSCArrays  {

	
   public static char[]  fill(char[] array_char, char val) {
	   Arrays.fill(array_char,val);
	   return array_char;
   }
}
