package it.ssc.metadata.exception;

public class TypeSqlNotSupported extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public TypeSqlNotSupported(String message) {
		super(message);
	}
}
