package it.ssc.step.exception;

public class ErrorStepInvocation extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ErrorStepInvocation(String message) {
		super(message);
	}
}
