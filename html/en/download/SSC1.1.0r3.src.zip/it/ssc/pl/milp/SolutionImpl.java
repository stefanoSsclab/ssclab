package it.ssc.pl.milp;

import java.util.ArrayList;

class SolutionImpl implements Solution {
	
	private Var[] variables;
	private MilpProblem milp_original;
	private SolutionType type_solution;
	
	SolutionImpl(SolutionType type_solution,MilpProblem milp_original,  int basis[],double values[]) {
		
		this.type_solution=type_solution;
		this.milp_original=milp_original;
		variables= milp_original.getVariables();
		int index_var=0;
		int index_base=0,index_p1_base=0;
		for(Var var:variables) {
			
			if(var.isFree()) {
				double value_sum=0;
				if((index_base=getIndexInBase( basis,index_var))!=-1) {
					value_sum=values[index_base];
				}	
				
				if((index_p1_base=getIndexInBase( basis,index_var+1))!=-1) {
					value_sum-=values[index_p1_base];
				}
				var.setValue(value_sum);
				index_var++;
			}
			else if((index_base=getIndexInBase( basis,index_var))!=-1) {
				var.setValue(values[index_base]);
			}

			index_var++;
		}
	}	
	
	public SolutionType getTypeSolution() {
		return type_solution;
	}
	
	public Var[] getVariables() {
		return this.variables;
	}
	
	private int  getIndexInBase( int basis[],int index) {
		for (int i = 0; i < basis.length; i++) {
			if(index== basis[i]) {
				return i;
			}
		}
		return -1;
	}
	
	public double getOptimumValue() {
		double z=0;
		ObjectiveFunctionImpl fo=this.milp_original.getObjFunction();
		for (int i = 0; i < variables.length; i++) {
			z+=variables[i].getValue()*fo.getCj(i);
		}
		return z;
	}

	public ObjectiveFunction getObjectFunction() {
		return this.milp_original.getObjFunction();
	}
	
	
	public SolutionConstraint[] getSolutionConstraint() {
		
		ArrayList<InternalConstraint> list_const=milp_original.getListConstraint();
		SolutionConstraintImpl[] sol_const=new SolutionConstraintImpl[list_const.size()];
		int _i=0;
		for(InternalConstraint internal_const:list_const)  {			
			sol_const[_i++]=new SolutionConstraintImpl(internal_const.getAi(), 
														 internal_const.getBi(), 
														 internal_const.getConsType(), 
														 variables);
			String name=internal_const.getName();
			if(name==null) name="row"+_i;
			sol_const[_i-1].setName(name);
			
		}
		return sol_const;
	}
}
