package it.ssc.pl.milp;

import java.util.HashMap;

class Tree {
	private HashMap<Integer,ManagerMILP> tree ;
	public Tree() {
		tree=new HashMap<Integer,ManagerMILP> ();
	}
	
	public ManagerMILP getMilpBestUP() { 
		ManagerMILP milp_best=null; 
		for(ManagerMILP milp :tree.values()) {
			if(milp_best==null) milp_best=milp;
			else if(milp_best.getOptimumValue() < milp.getOptimumValue()) milp_best=milp;
		}
		return milp_best;
	}
	
		
		
	public boolean isEmpty() {
		return tree.isEmpty();
	}
	
	public void addNode(ManagerMILP milp) {
		tree.put(milp.getId(), milp);
	}
	
	public  void deleteNode(ManagerMILP milp) {
		tree.remove(milp.getId());
	}
	
	public void deleteNodeWhitUPnotValide(double lb) {
		HashMap<Integer,ManagerMILP> tree_clone=(HashMap<Integer,ManagerMILP>)tree.clone();
		for(ManagerMILP milp :tree_clone.values()) {
			if(milp.getOptimumValue() <= lb)  { 
				tree.remove(milp.getId());
				//System.out.println("up SCADUTO - RIMOSSO PROBLEMA ID:"+milp.getId() +"z: "+milp.getUP() +" con LB:"+lb);
			}
		}
	}
}
