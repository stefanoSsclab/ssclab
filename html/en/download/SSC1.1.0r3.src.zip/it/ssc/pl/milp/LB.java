package it.ssc.pl.milp;

 class LB implements Comparable<LB> {
	 double value;
	 ManagerMILP milp;
	 
	 LB() {

	 }
	 
	 /*
	 public LB(LB other) {
		 this.value=other.value;
		 this.milp=other.milp;
	 }
	 */
	 
	 public int compareTo(LB other) {
		 if(other==null) throw new  NullPointerException(); 
		 if(this.value==other.value)  return 0;
		 else if(this.value > other.value) return -1;
		 else return 1;
	 }
}
