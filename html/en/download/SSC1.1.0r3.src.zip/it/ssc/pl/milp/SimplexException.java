package it.ssc.pl.milp;

public class SimplexException extends Exception { 
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public SimplexException(String massage) {
		super(massage);
	}

}
