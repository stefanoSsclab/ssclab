package it.ssc.step.parallel;

@FunctionalInterface
public interface Parallelizable {
	public void run() throws Exception; 
}
