package it.ssc.pl.milp;

 interface Costant {
	
	public final static String MAX="MAX";
	public final static String MIN="MIN";
	public final static String UPPER="UPPER";
	public final static String LOWER="LOWER";
	
	public final static String GE="GE";
	public final static String LE="LE";
	public final static String EQ="EQ";
	
	public final static String INTEGER="INTEGER";
	public final static String BINARY="BINARY";
	public final static String SEMICONT="SEMICONT"; 

}
