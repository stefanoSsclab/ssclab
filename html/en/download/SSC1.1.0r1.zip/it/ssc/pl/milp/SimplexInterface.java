package it.ssc.pl.milp;

 interface SimplexInterface {
	
	public SolutionType phaseOne()  throws SimplexException ;
	public long getNumIterationPhaseOne();
	public long getNumIterationPhaseTotal() ;
	public SolutionType phaseTwo() throws SimplexException, CloneNotSupportedException;
	public double[] getFinalValuesBasisClone() ;
	public int[] getFinalBasisClone();
	public void setNumIterationMax(long num_iteration_max);
	public void setMilp(boolean isMilp) ;
	
}
