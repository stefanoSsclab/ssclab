package it.ssc.pl.milp;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.util.logging.Logger;

import it.ssc.log.SscLevel;
import it.ssc.log.SscLogger;
import it.ssc.vector_spaces.Matrix;
import it.ssc.vector_spaces.Vector;

/**
 * @author Scarioli
 */

 class Phase2Big extends Phase0Big {
	
	private final int n;
	private final int m;
	private int num_iteration_phase_prec;
	
	public void setNumIterationPhasePrec(int num_iteration_phase_prec) {
		this.num_iteration_phase_prec = num_iteration_phase_prec;
	}

	private static final Logger logger=SscLogger.getLogger();
	
	
	public Phase2Big(Matrix phase1, int[] basis_p1, Vector C1, long prec_num_iteration,BIGEPSILON epsilon) 	throws SimplexException {
		
		super(phase1.getNrow()-1,phase1.getNcolumn()-1,epsilon);
		this.iteration=prec_num_iteration;
		this.m = phase1.getNrow() - 1;
		this.n = phase1.getNcolumn() - 1;

		if (C1.getTipo() == Vector.TYPE_VECTOR.COLUMN) {
			C1.traspose();
		}
		
		this.basis = basis_p1;
		Vector C = updateC(phase1,C1);
		updateZ(phase1,C1);
		
		this.table_exended = updateTableExtended(phase1,C); 
	}
	
	public SolutionType resolve(long num_iteration)  {
		
		//printTable();
		
		long LOCAL_NUM_ITERATION=NUM_MAX_ITERATION;
		if(num_iteration > 0) LOCAL_NUM_ITERATION=num_iteration;
		
		int var_incoming=0,row_var_outgoing=0;
		
		for(;this.iteration < LOCAL_NUM_ITERATION;  this.iteration++) {
			if(isBaseDegenerate())  var_incoming = test_var_incoming_bland();
			else var_incoming = test_var_incoming();
			
			if (var_incoming == -1) {	
				return SolutionType.OPTIMUM; 
			} 
			
			if ((row_var_outgoing = test_var_outgoing(var_incoming)) == -1) { 
				return SolutionType.ILLIMITATUM;
			}

			pivoting(row_var_outgoing,var_incoming);
			setBases(row_var_outgoing,var_incoming);
			
			//printTable();
			//printBases();
		}
		
		logger.log(SscLevel.TIME,"Raggiunto il massimo numero di iterazioni "+(LOCAL_NUM_ITERATION));
		return SolutionType.MAX_ITERATIUM;
	}
	
	private void updateZ(Matrix phase1,Vector C)  {
		int dim_c=C.lenght();
		BigDecimal somma_valori=ZERO_BIG;
		for(int _j=0;_j<dim_c;_j++) {
			int row_bases=isIndexInBase(_j);
			if(row_bases > -1) {
				BigDecimal value_c=C.getBigCell(_j);
				BigDecimal value =phase1.getBigCell(row_bases, n).multiply(value_c, MathContext.DECIMAL128);
				somma_valori=somma_valori.subtract(value, MathContext.DECIMAL128);
			}
		}
		phase1.setBigCell(m, n, somma_valori);
	}
	
	
	private Vector updateC(Matrix phase1,Vector C1) {
		int dim_c=C1.lenght();
		Matrix somma_valori_C=new Matrix(dim_c,dim_c);
		for(int _j=0;_j<dim_c;_j++) {
			int row_bases=isIndexInBase(_j);
			BigDecimal value_c=C1.getBigCell(_j);
			
			if(row_bases > -1) {   //ATTENZIONEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE .setScale(SCALE, RoundingMode.HALF_DOWN)
				if( !(value_c.compareTo(ZERO_BIG)==0)) {
					for(int _k=0;_k<dim_c ;_k++) {
						if((isIndexInBase(_k) < 0)) {
							BigDecimal value =phase1.getBigCell(row_bases, _k).multiply(value_c, MathContext.DECIMAL128);
							somma_valori_C.setBigCell(_j, _k,value.multiply(NEG_ONE_BIG, MathContext.DECIMAL128));
						}
					}
				}
			}
			//se non e' in base
			else {
				somma_valori_C.setBigCell(_j, _j, value_c);
			}
		}
		
		Vector new_C=new Vector(dim_c,Vector.TYPE_VECTOR.ROW);  
		for(int _j=0;_j<dim_c;_j++) {
			for(int _k=0;_k<dim_c;_k++) {
				BigDecimal value=new_C.getBigCell(_k);
				value=value.add(somma_valori_C.getBigCell(_j,_k), MathContext.DECIMAL128);
				new_C.setBigCell(_k, value);
			}
		}
		return new_C;
	}
	
	private int  isIndexInBase(int index) {
		for (int i = 0; i < basis.length; i++) {
			if(index== basis[i]) {
				return i;
			}
		}
		return -1;
	}

	private Matrix updateTableExtended(Matrix phase1,Vector C) {
		for (int j = 0; j < n; j++) {
			phase1.setBigCell(m, j, C.getBigCell(j));
		}
		return phase1;
	}

	public Matrix getTableExtended() {
		return this.table_exended;
	}
	
	public double[] getValuesBases() {
		double[] values=new double[this.m];
		for(int _a=0;_a <this.m;_a++) {
			//values[_a]= table_exended.getBigCell(_a, this.n).setScale(SCALE, RoundingMode.HALF_DOWN).doubleValue();
			//System.out.println("VALUESSSE:"+values[_a]);
			values[_a]= table_exended.getBigCell(_a, this.n).doubleValue();
		}
		return values;
	}
}
