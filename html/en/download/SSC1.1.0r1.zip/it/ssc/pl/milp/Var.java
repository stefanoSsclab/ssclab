package it.ssc.pl.milp;

import it.ssc.log.SscLogger;
import java.util.logging.Level;
import java.util.logging.Logger;

class Var implements Cloneable, Variable {
	
	private static final Logger logger=SscLogger.getLogger();
	
	private String name;
	private TYPE_VAR type=TYPE_VAR.REAL;
	private Double upper;
	private Double lower;
	private boolean is_free;
	private double value;
	private boolean is_lower_modified=false;
	
	//parte per variabili semi-continue
	private Double upperSemicon; 
	private Double lowerSemicon; 
	private boolean   isSemicon;
	
	public Var() {
		lower=0.0;   //IMPORTANTE
		lowerSemicon=0.0;
		is_free=false;
	}
	
	
	public void resetUpperLower() {
		lower=0.0;   //IMPORTANTE
		upper=null;
		is_free=false;
		is_lower_modified=false;
	}
	
	public Double getUpperSemicon() {
		return upperSemicon;
	}

	public void setUpperSemicon(Double upperSemicon) {
		this.upperSemicon = upperSemicon;
	}

	public Double getLowerSemicon() {
		return lowerSemicon;
	}

	public void setLowerSemicon(Double lowerSemicon) {
		this.lowerSemicon = lowerSemicon;
	}

	public boolean isSemicon() {
		return isSemicon;
	}

	public void setSemicon(boolean isSemicon) {
		this.isSemicon = isSemicon;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public TYPE_VAR getType() {
		return type;
	}

	public void setType(TYPE_VAR type) {
		this.type = type;
	}

	public Double getUpper() {
		return upper;
	}

	public void setUpper(Double upper) throws LPException {
		if(upper!=null && upper < 0.0) {
			this.is_free=true;
			if(is_lower_modified) {
				if(lower!=null && lower > upper) {
					throw new LPException("Errore definizione degli upper e lower bound. Il lower ("+lower+") non puo' essere maggiore dell'upper ("+upper+")");
				}
			}
		}
		
		else if(upper!=null && lower!=null)  {
			if(lower > upper) throw new LPException("Errore definizione degli upper e lower bound. Il lower ("+lower+") non puo' essere maggiore dell'upper ("+upper+")");
		}
		this.upper = upper;
	}
	

	public Double getLower() {
		return lower;
	}
	

	public void setLower(Double lower) throws LPException {
		if(lower==null || lower < 0.0) is_free=true;
		
		if(upper!=null && lower!=null)  {
			if(lower > upper) throw new LPException("Errore definizione degli upper e lower bound. Il lower ("+lower+") non puo' essere maggiore dell'upper ("+upper+")");
		}
		this.lower = lower;
		is_lower_modified=true;
	}
	
	
	public boolean isFree() {
		return is_free;
	}

	public Var clone() {
	
		Var clone=null;
		try {
			clone=(Var)super.clone();
		} 
		catch (CloneNotSupportedException e) {
			logger.log(Level.SEVERE,"Clonazione it.ssc.pl.milp.Var",e);
		}
		return clone;
	}
	
	public Double getValue() {
		return this.value;
	}
	
	public void setValue(double val) {
		this.value=val;
	}
}
