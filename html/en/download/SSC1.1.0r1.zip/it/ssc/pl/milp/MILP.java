package it.ssc.pl.milp;

import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import it.ssc.context.Context;
import it.ssc.context.Session;
import it.ssc.context.exception.InvalidSessionException;
import it.ssc.log.SscLevel;
import it.ssc.log.SscLogger;
import it.ssc.pl.milp.ManagerMILP.VERSUS_SEPARATION;
import it.ssc.ref.Input;
import it.ssc.vector_spaces.MatrixException;

/**
 * Questa classe permette di eseguire e risolvere formulazioni di problemi di programmazione 
 * lineare misto intera e binaria. Il metodo utilizzato per la risoluzione di tali problemi di ottimizzazione 
 * &egrave; il metodo del simplesso abbinato a quello del Branch and Bound. 
 * 
 * @author Stefano Scarioli
 * @version 1.0
 * @see <a target="_new" href="http://www.ssclab.org">SSC Software www.sscLab.org</a>
 */

public class MILP {
	
	private static final EPSILON epsilon=EPSILON._1E_M10;
	private static final  EPSILON iepsilon=EPSILON._1E_M10; 
	private static final  EPSILON cepsilon=EPSILON._1E_M8;
	
	private static final Logger logger=SscLogger.getLogger(); 
	
	private ManagerMILP milp_initiale;
	private LB lb;
	private static final boolean isBigFalse=false;
	private int num_max_simplex  =10000;
	private int num_max_iteration=100000;
	
	
	{
		lb=new LB();
	}
	
	/**
	 * Costruttore di un oggetto MILP per la risoluzione di problemi formulati in formato a disequazioni contenute in stringhe. 
	 * In questo formato le variabili devono necessariamente chiamarsi X<sub>j</sub>, con l'indice j che parte da 1. Il terzo parametro 
	 * &egrave; la lista dei vincoli che non sono di tipo EQ,LE,GE, ma UPPER e LOWER e vanno rappresentati come oggetti Constraint. 
	 * 
	 * @param inequality Lista dei vincoli di tipo EQ, GE, LE sotto forma di disequazioni contenute in stringhe
	 * @param constraints Lista dei vincoli di tipo UPPER e LOWER rappresentati come oggetti Constraint
	 * @param fo  Un oggetto LinearObjectiveFunction che rappresenta la funzione obiettivo
	 * @throws Exception  Viene generata una eccezione se il problema non &egrave; formulato correttamente
	 */
	
	
	public MILP(ArrayList<String> inequality,ArrayList<Constraint> constraints,LinearObjectiveFunction fo) throws Exception  { 
		if(constraints==null || constraints.isEmpty()) throw new LPException("L'oggetto ArrayList dei Constraint non contiene elementi");
		int dimension=fo.getC().length;
		ConstraintFromString cfs=new ConstraintFromString(dimension, inequality,constraints);
		ArrayList<Constraint> new_constraints=cfs.getConstraint();
		this.milp_initiale = new ManagerMILP(fo, new_constraints);
		setAllEpsilon();
	}
	
	/**
	 * Costruttore di un oggetto MILP per la risoluzione di problemi formulati in formato a disequazioni contenute in stringhe. 
	 * In questo formato le variabili devono necessariamente chiamarsi X<sub>j</sub>, con l'indice j che parte da 1. 
	 * 
	 * @param inequality  Lista dei vincoli di tipo (EQ,GE,LE) sotto forma di disequazioni contenute in stringhe
	 * @param fo Un oggetto LinearObjectiveFunction che rappresenta la funzione obiettivo
	 * @throws Exception Viene generata una eccezione se il problema non &egrave; formulato correttamente 
	 */
	
	
	public MILP(ArrayList<String> inequality,LinearObjectiveFunction fo) throws Exception  { 
		if(inequality==null || inequality.isEmpty()) throw new LPException("La ArrayList delle disequazioni non contiene elementi");
		int dimension=fo.getC().length;
		ConstraintFromString cfs=new ConstraintFromString(dimension, inequality);
		ArrayList<Constraint> new_constraints=cfs.getConstraint();
		this.milp_initiale = new ManagerMILP(fo, new_constraints);
		setAllEpsilon();
	}
	
	/**
	 * Costruttore di un oggetto MILP per la risoluzione di problemi espressi in formato matriciale.
	 * 
	 * @param fo Un oggetto LinearObjectiveFunction che rappresenta la funzione obiettivo
	 * @param constraints La lista dei vincoli 
	 * @throws Exception Viene generata una eccezione se il problema non &egrave; formulato correttamente 
	 * 
	 */
	
	public MILP(LinearObjectiveFunction fo,ArrayList<Constraint> constraints) throws  Exception {
		this.milp_initiale = new ManagerMILP(fo, constraints);
		setAllEpsilon();
	}
	

	/**
	 * Costruttore di un oggetto MILP per la risoluzione di problemi espressi in formato naturale.
	 * 
	 * @param input_natural Il problema formulato col formato naturale (a coefficenti)
	 * @throws Exception Viene generata una eccezione se il problema &egrave; formulato in modo non corretto
	 */
	
	public MILP(Input input_natural) throws  Exception {
		Session session=Context.createNewSession();
		this.milp_initiale = new ManagerMILP(input_natural, session); 
		logger.log(Level.INFO,"Fine utilizzo sessione SSC per importazione dati per MILP.");
		session.close();
		setAllEpsilon();
	}
	
	/**
	 * Costruttore di un oggetto MILP per la risoluzione di problemi espressi in formato naturale.
	 * 
	 * @param input_natural Il problema formulato col formato naturale
	 * @param session Una sessione di lavoro SSC 
	 * @throws Exception Viene generata una eccezione se il problema &egrave; formulato in modo non corretto
	 */
	
	public MILP(Input input_natural,Session session) throws  Exception {
		this.milp_initiale = new ManagerMILP(input_natural, session); 
		setAllEpsilon();
	}
	
	/**
	 *  Costruttore di un oggetto MILP per la risoluzione di problemi espressi in formato sparso.
	 * 
	 * @param input_sparse Il problema formulato col formato sparso 
	 * @param session Una sessione di lavoro SSC 
	 * @throws Exception Viene generata una eccezione se il problema &egrave; formulato in modo non corretto
	 */
	
	public MILP(InputSparse input_sparse,Session session) throws Exception {
		this.milp_initiale = new ManagerMILP(input_sparse, session); 
		setAllEpsilon();
	}
	
	/**
	 * Costruttore di un oggetto MILP per la risoluzione di problemi espressi in formato sparso.
	 * 
	 * @param input_sparse Il problema formulato col formato sparso
	 * @throws Exception Viene generata una eccezione se il problema &egrave; formulato in modo non corretto
	 */
	
	public MILP(InputSparse input_sparse) throws  Exception {
		Session session=Context.createNewSession();
		this.milp_initiale = new ManagerMILP(input_sparse, session);
		logger.log(Level.INFO,"Fine utilizzo sessione SSC per importazione dati per MILP.");
		session.close();
		setAllEpsilon();
	}
	
	/**
	 * 
	 * @return il numero massimo di iterazioni eseguibile da ciascun simplesso
	 */
	

	public int getNumMaxIterationForSingleSimplex() {
		return num_max_iteration;
	}
	
	/**
	 * Metodo per settare il nunmero di iterazioni di ogni singolo simplesso 
	 * 
	 * @param num_max_iteration Il numero massimo di iterazioni eseguibili da ciascun simplesso
	 * @throws SimplexException Se si genera un errore durante il processo 
	 */

	public void setNumMaxIterationForSingleSimplex(int num_max_iteration) throws SimplexException {
		if(num_max_iteration <= 0) throw new SimplexException("Il numero massimo di iterazioni deve essere un numero positivo");
		this.num_max_iteration = num_max_iteration;
	}
	
	/**
	 * 
	 * @return il numero massimo di simplessi eseguibili nel procedimento del branch and bound 
	 */

	public int getNumMaxSimplexs() {
		return num_max_simplex;
	}
	
	/**
	 * MEtodo per impostare il nunmero massimo di simplessi
	 * 
	 * @param num_max_simplex il numero massimo di simplessi eseguibili nel procedimento del branch and bound 
	 */

	public void setNumMaxSimplexs(int num_max_simplex) {
		this.num_max_simplex = num_max_simplex;
	}

	private void setAllEpsilon() {
		this.milp_initiale.setEpsilon(epsilon);
		this.milp_initiale.setIEpsilon(iepsilon); 
		this.milp_initiale.setCEpsilon(cepsilon); 
	}
	
	/**
	 * Questo metodo permette di settare il valore epsilon relativo alla tolleranza che interviene in diversi ambiti del simplesso. &Egrave;  
	 * utilizzato nei seguenti casi : <br>
	 * 
	 * 1) Durante la fase uno, sia nella determinazione delle variabile entrante che in quella della variabile uscente con o senza regola di Bland. 
	 *    Sia per determinare se la base &egrave; degenere. Viene anche utilizzata alla fine della fase uno : se esiste una variabile ausiliaria in base, 
	 *    epsilon viene utilizzato per determinare se &egrave; possibile eliminare le righe e le colonne di queste sulla tabella estesa.  <br>
	 * 2) Durante la fase due , sia nella determinazione delle variabile entrante che in quella della variabile uscente con o senza regola di BLand. 
	 *    Sia per determinare se la base &egrave; degenere.   
	 * 
	 * @param epsilon Toleranza utilizzata in diverse fasi del simplesso. Valore default 1-E10
	 */
	
	public void setEpsilon(EPSILON epsilon) {
		this.milp_initiale.setEpsilon(epsilon);
	}
	
	/**
	 * Questo metodo permette di settare il valore epsilon relativo alla tolleranza per 
	 * determinare se una soluzione ottima della fase 1 del simplesso &egrave; prossima o uguale a zero e quindi da origine a 
	 * soluzioni ammissibili per il problema . 
	 * 
	 * @param cepsilon Tolleranza soluzione fase 1 rispetto allo zero. Valore default 1-E8
	 */
	
	public void setCEpsilon(EPSILON cepsilon) {
		this.milp_initiale.setCEpsilon(cepsilon);
	}
	
	/**
	 * Questo metodo permette di settare il valore epsilon relativo alla tolleranza per 
	 * determinare se un numero deve essere considerato intero o no. Questo controllo 
	 * avviene quando alla fine del simplesso si valuta se la soluzione trovata soddisfa la condizione di interezza 
	 * sulle variabili che devono esserlo.  Sia x un numero e sia Int(x) l'intero pi&ugrave; vicino a x, se 
	 *  | Int(x) - x | &lt; epsilon -&gt; x &#x2208; &#x2124;
	 * 
	 * @param iepsilon Tolleranza per considerare un numero come intero. Valore default 1-E10
	 */
	
	public void setIEpsilon(EPSILON iepsilon) {
		this.milp_initiale.setIEpsilon(iepsilon); 
	}
	
	/**
	 * Esegue il branch and bound .
	 * 
	 * @return Il tipo di soluzione trovata 
	 * @throws Exception Se il processo di esecuzione genera un errore 
	 */
	
	
	public SolutionType resolve() throws Exception {
		
		int num_simplex_resolved=1;
		long start=System.currentTimeMillis();
		
		ManagerMILP milp_current=milp_initiale;    //INIZIALMENTE E' QUELLO INIZIALE (!)
		milp_current.setMaxIteration(num_max_iteration);
		Tree tree=new Tree();
		
		SolutionType type_solution_initial=milp_current.resolve(isBigFalse); 
		lb.value=Double.NEGATIVE_INFINITY; 
		if(type_solution_initial==SolutionType.OPTIMUM) {
			tree.addNode(milp_current);
		}	 
		
		SolutionType type_solution=SolutionType.VUOTUM;
		while(!tree.isEmpty()) {
			milp_current=tree.getMilpBestUP();   //POI DIVENTE QUELLO CORRENTE  (!)
			//System.out.println("prob:"+milp_current.getId()+" z:"+milp_current.getUP());
			if(milp_current.isSolutionIntegerAmmisible() && milp_current.isProblemSemiContinusAmmisible()) {
				milp_current.setIntegerIfOptimal();
				//System.out.println("SOLUZIONE INTERA:"+milp_current.getId()+" z:"+milp_current.getOptimumValue());
				if(lb.value < milp_current.getOptimumValue()) {
					//System.out.println("SOLUZIONE INTERA MIGLIORE:"+milp_current.getId()+" z:"+milp_current.getUP());
					lb.value= milp_current.getOptimumValue();
					lb.milp=milp_current;
					type_solution=SolutionType.OPTIMUM; 
				}
				
			}
			
			else {
				ManagerMILP milp_sotto=null;
				ManagerMILP milp_sopra=null;
				if(!milp_current.isProblemSemiContinusAmmisible()) {
					int index_var_not_cont=milp_current.getIndexVarToBeSemiContinus();
					milp_sotto=milp_current.getCloneBySeparationContinus(index_var_not_cont, VERSUS_SEPARATION.ZERO);
					milp_sopra=milp_current.getCloneBySeparationContinus(index_var_not_cont, VERSUS_SEPARATION.INTERVAL);
				}
				else {
					int index_var_not_integer=milp_current.getIndexVarToBeInteger();
					//System.out.println("DIVIDO PROBLEMA ID:"+milp_current.getId()+" z:"+milp_current.getOptimumValue());
					milp_sotto=milp_current.getCloneBySeparation(index_var_not_integer, VERSUS_SEPARATION.MINOR);
					milp_sopra=milp_current.getCloneBySeparation(index_var_not_integer, VERSUS_SEPARATION.MAJOR);
					
				}
				
				SolutionType type_solution_sotto=milp_sotto.resolve(isBigFalse);
				num_simplex_resolved++;
				if(type_solution_sotto==SolutionType.OPTIMUM) {
					//System.out.println("OTTIMO SOTTO ID:"+milp_sotto.getId()+" z:"+milp_sotto.getOptimumValue());
					tree.addNode(milp_sotto);
				}
				
				SolutionType type_solution_sopra=milp_sopra.resolve(isBigFalse); //valutaree se un pi� thread
				num_simplex_resolved++;
				if(type_solution_sopra==SolutionType.OPTIMUM) {
					//System.out.println("OTTIMO SOPRA ID:"+milp_sopra.getId()+" z:"+milp_sopra.getOptimumValue());
					tree.addNode(milp_sopra);
				}
				tree.deleteNodeWhitUPnotValide(lb.value); 
			}
			tree.deleteNode(milp_current);
			
			if(num_simplex_resolved >= num_max_simplex) { 
				logger.log(SscLevel.WARNING,"Si e' superato il numero massimo di simplessi eseguibili :"+num_max_simplex);
				logger.log(SscLevel.NOTE,"Il numero massimo di simplessi eseguibili puo' essere modificato con il metodo setNumMaxSimplexs()");
				return SolutionType.MAX_NUM_SIMPLEX;
			}
		}
		
		long end=System.currentTimeMillis();
		logger.log(SscLevel.TIME,"Durata processo BRANCH AND BOUND "+(end-start)+" millisecondi");
		logger.log(SscLevel.INFO,"Numero di simplessi eseguiti sui nodi : "+num_simplex_resolved);
		return type_solution;

	}
	/**
	 * Questo metodo restituisce la soluzione del problema eliminando i vincoli di interezza. 
	 * Se vi sono variabili binarie , viene solo tolto il vincolo dall'assumere valori interi, ma  
	 * alla variabile binaria rimane il vincolo  di essere compresa tra zero ed uno . 
	 * 
	 * @return restituisce la soluzione rilassata, ovvero la soluzione del problema senza vincoli di interezza. 
	 * 
	 */
	
	public Solution getRelaxedSolution()  {
		if(milp_initiale!=null) return milp_initiale.getSolution();
		else return null;
		
	}
	
	/**
	 * Questo metodo restituisce, se esiste, la soluzione ottima intera, misto intera o binaria 
	 * 
	 * @return  la soluzione ottima intera, misto intera o binaria 
	 */
	
	public Solution getSolution()  {
		if(lb.milp!=null) return lb.milp.getSolution();
		else return null;
		
	}
}
