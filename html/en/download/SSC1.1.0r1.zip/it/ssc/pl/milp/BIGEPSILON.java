package it.ssc.pl.milp;

import java.math.BigDecimal;

import java.math.MathContext;
/**
 * 
 * @author Stefano Scarioli 
 * @version 1.0
 * @see <a target="_new" href="http://www.ssclab.org">SSC Software www.sscLab.org</a>
 */


enum BIGEPSILON {
	
	
		E1_M24 (new BigDecimal("1E-24",MathContext.DECIMAL128)),
		E1_M23 (new BigDecimal("1E-23",MathContext.DECIMAL128)),
		E1_M22 (new BigDecimal("1E-22",MathContext.DECIMAL128)),
		E1_M21 (new BigDecimal("1E-21",MathContext.DECIMAL128)),
		E1_M20 (new BigDecimal("1E-20",MathContext.DECIMAL128)),
		E1_M19 (new BigDecimal("1E-19",MathContext.DECIMAL128)),
		E1_M18 (new BigDecimal("1E-18",MathContext.DECIMAL128)),
		E1_M17 (new BigDecimal("1E-17",MathContext.DECIMAL128)),
		E1_M16 (new BigDecimal("1E-16",MathContext.DECIMAL128)),
		E1_M15 (new BigDecimal("1E-15",MathContext.DECIMAL128));
		
		private BigDecimal eps_value;
		private BIGEPSILON(BigDecimal epsilon) {
			this.eps_value=epsilon;
		}
		
		public BigDecimal getValue() {
			return this.eps_value;
		}
	}



