package it.ssc.pl.milp;

import it.ssc.log.SscLogger;
import java.util.logging.Level;
import java.util.logging.Logger;

class InternalConstraint implements Cloneable {
	
	

	private static final Logger logger=SscLogger.getLogger();
	public enum TYPE_CONSTR {EQ, LE, GE}; 
	private Double[] Ai;
	private Double bi;
	private TYPE_CONSTR type;
	private String name;
	
	
	public InternalConstraint(int dimension) {
		Ai=new Double[dimension];
	}
	
	
	
	public Double[] getAi() {
		return Ai;
	}
	
	public void setAij(int j, Double aij) {
		Ai[j]=aij;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Double getAij(int j) {
		return Ai[j];
	}
	
	public void setBi(Double bi) {
		this.bi = bi;
	}
	
	public Double getBi() {
		return bi;
	}

	public TYPE_CONSTR getType() {
		return type;
	}
	
	public ConsType getConsType() {
		if(type==TYPE_CONSTR.EQ) return ConsType.EQ;
		else if(type==TYPE_CONSTR.LE)  return ConsType.LE;
		else if(type==TYPE_CONSTR.GE)  return ConsType.GE;
		else return null;
	}

	public void setType(TYPE_CONSTR type) {
		this.type = type;
	}
	
	public void standardize() {
		if(bi < 0.0) {
			bi=-bi;
			for(int j=0;j<Ai.length;j++) {
				if(Ai[j]!=0.0)  Ai[j]=-Ai[j];
			}
			if(type==TYPE_CONSTR.GE) type=TYPE_CONSTR.LE;
			else if(type==TYPE_CONSTR.LE) type=TYPE_CONSTR.GE;
		}
	}
	
	public static InternalConstraint createConstraintFromVar(int dim,int index,Double value, TYPE_CONSTR ltype) {
		InternalConstraint l_constraint =new InternalConstraint(dim);
		for(int j=0;j<dim;j++) {
			if(j==index)  l_constraint.Ai[j]=1.0;
			else l_constraint.Ai[j]=0.0;
			l_constraint.bi=value;
			//System.out.println("mmmm:"+value);
			l_constraint.type=ltype;
		}
		return l_constraint;
	}
	
	public void aprint() {
		for(int j=0;j<Ai.length;j++) {
			System.out.print(Ai[j]+"\t");
		}
		System.out.print(type+"\t");
		System.out.print(bi+"\n");
	}
	
	public InternalConstraint clone() {
		InternalConstraint clone=null;
		try {
			clone=(InternalConstraint)super.clone();
			clone.Ai=(Double[])Ai.clone();
		} 
		catch (CloneNotSupportedException e) {
			logger.log(Level.SEVERE,"Clonazione it.ssc.pl.milp.Constraint",e);
		}
		return clone;
	}
}
