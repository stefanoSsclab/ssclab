package it.ssc.pl.milp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.TreeSet;
import java.util.logging.Logger;

import it.ssc.datasource.DataSource;
import it.ssc.datasource.DataSourceException;
import it.ssc.log.SscLevel;
import it.ssc.log.SscLogger;

 class CreateMilpProblem implements Costant  {
	 
	 private static final Logger logger=SscLogger.getLogger();
	 
	 
	 public static MilpProblem create(LinearObjectiveFunction f,
			 						  ArrayList<Constraint> constraints,
			 						  boolean isMilp) throws Exception  {

		 checkDimensionProblem(f,constraints);
	
		 boolean exist_integer_var=false;
		 boolean is_set_row_upper=false;
		 boolean is_set_row_lower=false;
		 boolean is_set_row_binary=false;
		 boolean is_set_row_integer=false;
		 boolean is_set_row_semicont=false;
		
		 double[] C=f.getC();
		 int N=C.length;
		 MilpProblem milp_original=new MilpProblem(N);
		 for(int _j=0;_j<N; _j++)  {
			 milp_original.setNameVar(_j, "X"+(_j+1));
		 }

		 if(f.getType()==GoalType.MAX) milp_original.setTargetObjFunction(MAX);
		 else if(f.getType()==GoalType.MIN) milp_original.setTargetObjFunction(MIN);
		 for(int _j=0;_j<N; _j++)  {
			 milp_original.setCjOF(_j, C[_j]);
		 }

		 for(Constraint constraint:constraints) {

			 ConsType rel=constraint.getRel();

			 if(rel==ConsType.EQ || rel==ConsType.GE || rel==ConsType.LE) {
				 InternalConstraint constraint_i=new InternalConstraint(N) ;
				 Double double_b=constraint.getRhs();
				 if(double_b==null) throw new LPException("I coefficienti Bi (RHS) non possono essere missing. ");
				 constraint_i.setBi(double_b);
				 	//System.out.println("ddddd:"+double_b);
				 
				 Double[] Aj=constraint.getAj();
				 for(int _j=0;_j<N; _j++)  {
					 Double double_val=Aj[_j];
					 if(double_val==null) throw new LPException("I coefficienti Aij della matrice dei coefficienti non possono essere missing. Se la variabile ha coefficiente zero inserire zero");
					 constraint_i.setAij(_j, double_val);
				 }

				 if(rel==ConsType.LE) constraint_i.setType(InternalConstraint.TYPE_CONSTR.LE);
				 else if(rel==ConsType.GE ) constraint_i.setType(InternalConstraint.TYPE_CONSTR.GE);
				 else if(rel==ConsType.EQ ) constraint_i.setType(InternalConstraint.TYPE_CONSTR.EQ);

				 milp_original.addConstraint(constraint_i);

			 }


			 else if(rel==ConsType.LOWER || rel==ConsType.UPPER) {

				 if(rel==ConsType.UPPER  ) { 
					 if(is_set_row_upper) throw new LPException("La riga che esprime gli UPPER deve essere unica. Eliminare doppione");
					 else is_set_row_upper=true;
				 }
				 if(rel==ConsType.LOWER  ) { 
					 if(is_set_row_lower) throw new LPException("La riga che esprime i LOWER deve essere unica. Eliminare doppione");
					 else is_set_row_lower=true;
				 }

				 Double[] Aj=constraint.getAj();
				 for(int _j=0;_j<N; _j++)  {
					 Var xj=milp_original.getVar(_j);
					 Double bound_val=Aj[_j];
					 if(rel==ConsType.UPPER) xj.setUpper(bound_val);
					 if(rel==ConsType.LOWER ) xj.setLower(bound_val);
				 }
			 }


			 //FACOLTATIVO, UNA SOLA VOLTA, esclusivo o binary o integer
			 else if(rel==ConsType.BIN || rel==ConsType.INT || rel==ConsType.SEMICONT ) {
				 exist_integer_var=true;
				 if(!isMilp) throw new LPException("In un problema di progammazione lineare LP non possono essere definite variabili intere o binarie o semicontinue. Usare la classe MILP.");

				 if(rel==ConsType.BIN ) { 
					 if(is_set_row_binary) throw new LPException("La riga che esprime le variabili BINARIE deve essere unica. Eliminare doppione");
					 else is_set_row_binary=true;
				 }
				 if(rel==ConsType.INT ) { 
					 if(is_set_row_integer) throw new LPException("La riga che esprime le variabili INTERE deve essere unica. Eliminare doppione");
					 else is_set_row_integer=true;
				 }
				 
				 if(rel==ConsType.SEMICONT ) { 
					 if(is_set_row_semicont) throw new LPException("La riga che esprime le variabili SEMICONTINUE deve essere unica. Eliminare doppione");
					 else is_set_row_semicont=true;
				 }

				 Double[] Aj=constraint.getAj();

				 for(int _j=0;_j<N; _j++)  {

					 Var xj=milp_original.getVar(_j);
					 Double type_var=Aj[_j];

					 if(type_var!=null && type_var==1.0) {
						 //System.out.println("VAR  "+_j +"  "+type);
						 if(rel==ConsType.INT) { 
							 if(xj.getType()==Var.TYPE_VAR.BINARY) throw new LPException("La variabile numero "+(_j+1)+" non puo' essere INTEGER  e' stata gia definita BYNARY");
							 xj.setType(Var.TYPE_VAR.INTEGER);
						 }
						 if(rel==ConsType.BIN)  {
							 if(xj.getType()==Var.TYPE_VAR.INTEGER) throw new LPException("La variabile numero "+(_j+1)+" non puo' essere BYNARY e' stata gia definita INTEGER");
							 xj.setType(Var.TYPE_VAR.BINARY);
						 }
						 
						 if(rel==ConsType.SEMICONT)  {
							 if(xj.getType()==Var.TYPE_VAR.BINARY) throw new LPException("La variabile numero "+(_j+1)+" non puo' essere SEMICONT e' stata gia definita BYNARY");
							 xj.setSemicon(true);;
						 }
						 
					 }
					 else if(type_var==null || type_var!=0.0) {
						 if(rel==ConsType.INT) throw new LPException("Per definire o no una variabile INTERA si deve valorizzare la riga INTEGER solo con i valori (0,1)");
						 if(rel==ConsType.BIN) throw new LPException("Per definire o no una variabile BINARIA si deve valorizzare la riga dei BINARY solo con i valori (0,1)");
						 if(rel==ConsType.SEMICONT) throw new LPException("Per definire o no una variabile SEMICONTINUA si deve valorizzare la riga dei BINARY solo con i valori (0,1)");
					 }
				 }
			 }
		 }
		 if(isMilp && !exist_integer_var) logger.log(SscLevel.WARNING,"Attenzione ! Per ragioni di performance si consiglia di usare la procedura LP in sostituzione della MILP"+
				                                                      "in quanto il problema non presenta varaibili di tipo intero o binario");
		 return milp_original;
	 }


	
	//ATTENZIONE FARE TUTTI i CONTROLLI 
	
	public static MilpProblem create(DataSource milp_data_source,boolean isMilp) throws Exception  {
		
		boolean exist_integer_var=false;
		boolean is_set_row_obj_function=false;
		boolean is_set_row_upper=false;
		boolean is_set_row_lower=false;
		boolean is_set_row_binary=false;
		boolean is_set_row_integer=false;
		boolean is_set_row_semicont=false;
		
		int size=milp_data_source.getNumColunm();
		/*Calcola il numero delle variabili del problema, numero colonne -2 */
		int N=size-2;
		/*Crea un problema con N variabili */
		MilpProblem milp_original=new MilpProblem(N);
		
		boolean exist_column_type=false; 
		boolean exist_column_rhs=false;  
		for(int _a=0;_a<size; _a++)  {
			String name=milp_data_source.getNameColunm(_a);
			//System.out.println("NAMME:"+name);
			
			if(name.equalsIgnoreCase("TYPE")) {
				exist_column_type=true;
			}
			if(name.equalsIgnoreCase("RHS")) {  
				exist_column_rhs=true;
			}
		}
		if(!exist_column_type) throw  new LPException("La variabile TYPE non e' stata definita");
		if(!exist_column_rhs)  throw  new LPException("La variabile RHS non e' stata definita");
		
		
		for(int _a=0,_j=0;_a<size; _a++)  {
			String name=milp_data_source.getNameColunm(_a);
			
			if(!(name.equalsIgnoreCase("TYPE") || name.equalsIgnoreCase("RHS"))) { 
				milp_original.setNameVar(_j, name);
				_j++;
			}
		}
	
		/*Inserire la riga di errore !!!!!!!!! */
		
		
	
		while(milp_data_source.next()) { 
			String type=milp_data_source.getString("TYPE");
			//System.out.println("TYPE"+type);
			if(type==null) throw new LPException("La varibile TYPE va valorizzata con i seguenti valori : (MIN,MAX,EQ,LE,GE,UPPER,LOWER,BINARY,INTEGER) ");
			//OBLIGATORIO, UNA SOLA VOLTA
			if(type.equalsIgnoreCase(MAX)|| type.equalsIgnoreCase(MIN)) {
				if(is_set_row_obj_function) {
					throw new LPException("In un problema di programmazione lineare la funzione obiettivo e' unica. Eliminare il rigo con l'ulteriore valore della colonna TYPE="+type );
				}
				is_set_row_obj_function=true;
				
				milp_original.setTargetObjFunction(type);
				for(int _a=0,_j=0;_a<size; _a++)  {
					
					String name=milp_data_source.getNameColunm(_a);
					if(!(name.equalsIgnoreCase("TYPE") || name.equalsIgnoreCase("RHS"))) {
						Double double_val=milp_data_source.getDouble(_a);
						if(double_val==null) throw new LPException("I coefficienti della funzione obiettivo non possone essere missing. Se la variabile ha coefficiente zero inserire zero");
						milp_original.setCjOF(_j, double_val);
						_j++;
					}
				}
			}
			else if(type.equalsIgnoreCase(LE) || 
					type.equalsIgnoreCase(GE) ||  
					type.equalsIgnoreCase(EQ)) {
				
				InternalConstraint constraint_i=new InternalConstraint(N) ;
				
				for(int _a=0,_j=0;_a<size; _a++)  {
					
					String name=milp_data_source.getNameColunm(_a);
					if(!name.equalsIgnoreCase("TYPE") ) {
						if(name.equalsIgnoreCase("RHS")) {
							Double double_val=milp_data_source.getDouble(_a);
							if(double_val==null) throw new LPException("I coefficienti Bi (RHS) non possono essere missing. ");
							constraint_i.setBi(double_val);
						}
						else {
							Double double_val=milp_data_source.getDouble(_a);
							if(double_val==null) throw new LPException("I valori Aij della matrice dei coefficienti relativi ai vincoli (EQ,LE,GE) non possono essere missing (null). Se la variabile ha coefficiente zero inserire zero");
							constraint_i.setAij(_j, double_val);
						}
						_j++;
					}
					else {
						if(type.equalsIgnoreCase(LE)) constraint_i.setType(InternalConstraint.TYPE_CONSTR.LE);
						else if(type.equalsIgnoreCase(GE)) constraint_i.setType(InternalConstraint.TYPE_CONSTR.GE);
						else if(type.equalsIgnoreCase(EQ)) constraint_i.setType(InternalConstraint.TYPE_CONSTR.EQ);
					}
				}
				milp_original.addConstraint(constraint_i);
			}
			
			//FACOLTATIVO, UNA SOLA VOLTA
			else if(type.equalsIgnoreCase(UPPER)|| type.equalsIgnoreCase(LOWER)) {
				
				if(type.equalsIgnoreCase(UPPER) ) { 
					if(is_set_row_upper) throw new LPException("La riga che esprime gli UPPER deve essere unica. Eliminare doppione");
					else is_set_row_upper=true;
				}
				if(type.equalsIgnoreCase(LOWER) ) { 
					if(is_set_row_lower) throw new LPException("La riga che esprime i LOWER deve essere unica. Eliminare doppione");
					else is_set_row_lower=true;
				}
				
				for(int _a=0,_j=0;_a<size; _a++)  {
					String name=milp_data_source.getNameColunm(_a);
					if(!(name.equalsIgnoreCase("TYPE") || name.equalsIgnoreCase("RHS"))) {
						Var xj=milp_original.getVar(_j);
						Double bound_val=milp_data_source.getDouble(_a);
						if(type.equalsIgnoreCase(UPPER)) xj.setUpper(bound_val);
						if(type.equalsIgnoreCase(LOWER)) xj.setLower(bound_val);
						_j++;
					}
				}
			}
			
			//FACOLTATIVO, UNA SOLA VOLTA, esclusivo o binary o integer
			else if(type.equalsIgnoreCase(BINARY)|| type.equalsIgnoreCase(INTEGER) || type.equalsIgnoreCase(SEMICONT)) {
				exist_integer_var=true;
				if(!isMilp) throw new LPException("In un problema di progammazione lineare LP non possono essere definite variabili intere o binarie o semicontinue. Usare la classe MILP");
				
				if(type.equalsIgnoreCase(BINARY) ) { 
					if(is_set_row_binary) throw new LPException("La riga che esprime le variabili BINARIE deve essere unica. Eliminare doppione");
					else is_set_row_binary=true;
				}
				if(type.equalsIgnoreCase(INTEGER) ) { 
					if(is_set_row_integer) throw new LPException("La riga che esprime le variabili INTERE deve essere unica. Eliminare doppione");
					else is_set_row_integer=true;
				}
				if(type.equalsIgnoreCase(SEMICONT) ) { 
					if(is_set_row_semicont) throw new LPException("La riga che esprime le variabili SEMICONTINUE deve essere unica. Eliminare doppione");
					else is_set_row_semicont=true;
				}
				
				
				for(int _a=0,_j=0;_a<size; _a++)  {
					String name=milp_data_source.getNameColunm(_a);
					if(!(name.equalsIgnoreCase("TYPE") || name.equalsIgnoreCase("RHS"))) {
						Var xj=milp_original.getVar(_j);
						Double type_var=milp_data_source.getDouble(_a);
						if(type_var!=null && type_var==1.0) {
							//System.out.println("VAR  "+_j +"  "+type);
							if(type.equalsIgnoreCase(INTEGER)) { 
								if(xj.getType()==Var.TYPE_VAR.BINARY) throw new LPException("La variabile "+name+" non puo' essere INTEGER  e' stata gia definita BYNARY");
								xj.setType(Var.TYPE_VAR.INTEGER);
							}
							if(type.equalsIgnoreCase(BINARY))  {
								if(xj.getType()==Var.TYPE_VAR.INTEGER) throw new LPException("La variabile "+name+" non puo' essere BYNARY e' stata gia definita INTEGER");
								if(xj.isSemicon()) throw new LPException("La variabile "+name+" non puo' essere BYNARY e' stata gia definita SEMICONTINUA");
								xj.setType(Var.TYPE_VAR.BINARY);
							}
							
							if(type.equalsIgnoreCase(SEMICONT))  {
								if(xj.getType()==Var.TYPE_VAR.BINARY) throw new LPException("La variabile "+name+" non puo' essere SEMICONTINUA e' stata gia definita BYNARY");
								xj.setSemicon(true);
							}
							
						}
						else if(type_var==null || type_var!=0.0) {
							if(type.equalsIgnoreCase(INTEGER)) throw new LPException("Per definire o no una variabile INTERA si deve valorizzare la riga INTEGER solo con i valori (0,1)");
							if(type.equalsIgnoreCase(BINARY))  throw new LPException("Per definire o no una variabile BINARIA si deve valorizzare la riga dei BINARY solo con i valori (0,1)");
							if(type.equalsIgnoreCase(SEMICONT))  throw new LPException("Per definire o no una variabile SEMICONTINUA si deve valorizzare la riga dei SEMICONT solo con i valori (0,1)");
						}
						_j++;
					}
				}
			}
			else {
				throw new LPException("La varibile TYPE puo' assumere solo i seguenti valori : (MIN,MAX,EQ,LE,GE,UPPER,LOWER,BINARY,INTEGER,SEMICONT) (valore presente:"+type+")"); 
			}
		}
		milp_data_source.close();
		
		if(isMilp && !exist_integer_var) logger.log(SscLevel.WARNING,"Attenzione ! Per ragioni di performance si consiglia di usare la procedura LP in sostituzione della MILP"+
         																" in quanto il problema non presenta variabili di tipo intero o binario");
		return milp_original;
	}
	
	
	
	public static MilpProblem createFromSparse(DataSource source_sparse,boolean isMilp) throws DataSourceException, Exception {
		HashMap<String,String> hash_row_type=new HashMap<String,String>(); 
		HashMap<String,HashMap<String, Double>> hash_row_col=new HashMap<String,HashMap<String, Double>>(); 
		TreeSet<String> tree_col=new TreeSet<String>();
		
		int size=source_sparse.getNumColunm();

		boolean exist_column_type=false; 
		boolean exist_column_col=false;  
		boolean exist_column_row=false; 
		boolean exist_column_coe=false; 
		for(int _a=0;_a<size; _a++)  {
			String name=source_sparse.getNameColunm(_a);

			if(name.equalsIgnoreCase("TYPE")) {
				exist_column_type=true;
			}
			if(name.equalsIgnoreCase("COL_")) {  
				exist_column_col=true;
			}
			if(name.equalsIgnoreCase("ROW_")) {  
				exist_column_row=true;
			}
			if(name.equalsIgnoreCase("COEF")) {  
				exist_column_coe=true;
			}
		}
		if(!exist_column_type) throw  new LPException("La variabile TYPE non e' stata definita");
		if(!exist_column_col)  throw  new LPException("La variabile COL_ non e' stata definita");
		if(!exist_column_row)  throw  new LPException("La variabile ROW_ non e' stata definita");
		if(!exist_column_coe)  throw  new LPException("La variabile COEF non e' stata definita");


		int num_row=0;	
		while(source_sparse.next()) { 
			num_row++;
			String type=source_sparse.getString("TYPE");
			if(type!=null) {
				type=type.toUpperCase();
				if(!(type.equals(MAX)   || type.equals(MIN)    || type.equals(GE)      || 
					 type.equals(LE)    || type.equals(EQ)     || type.equals(UPPER)   || 
					 type.equals(LOWER) || type.equals(BINARY) || type.equals(INTEGER) || 
					 type.equals(SEMICONT) )) { 
					
					 throw new LPException("La variabile TYPE puo' assumere solo i seguenti valori : (MIN,MAX,EQ,LE,GE,UPPER,LOWER,BINARY,INTEGER) (valore presente:"+type+")");	
				}
				
				if(type.equalsIgnoreCase(BINARY) || type.equalsIgnoreCase(INTEGER) || type.equalsIgnoreCase(SEMICONT)) {
					if(!isMilp) throw new LPException("In un problema di progammazione lineare LP non possono essere definite variabili intere o binarie o semicontinue. Usare la classe MILP.");
				}	
				
				if(type.equals(MAX) && ( hash_row_type.containsValue(MIN) || hash_row_type.containsValue(MAX)) ) {
					throw new LPException("La variabile TYPE non puo' assumere di nuovo un valore della f.o. MAX. Questo valore e' stato impostato precendente. Riga :"+num_row);
				}
				else if(type.equals(MIN) && ( hash_row_type.containsValue(MIN) || hash_row_type.containsValue(MAX))) {
					throw new LPException("La variabile TYPE non puo' assumere di nuovo un valore della f.o. MIN. Questo valore e' stato impostato precendente. Riga :"+num_row);
				}
				
				if(type.equals(UPPER) && hash_row_type.containsValue(UPPER)  ) {
					throw new LPException("La variabile TYPE non puo' di nuovo assumere il valore UPPER. Questo valore e' stato impostato precendente. Riga :"+num_row);
				}
				if(type.equals(LOWER) && hash_row_type.containsValue(LOWER)  ) {
					throw new LPException("La variabile TYPE non puo' di nuovo assumere il valore LOWER. Questo valore e' stato impostato precendente. Riga :"+num_row);
				}
				if(type.equals(BINARY) && hash_row_type.containsValue(BINARY)  ) {
					throw new LPException("La variabile TYPE non puo' assumere di nuovo il valore BINARY. Questo valore e' stato impostato precendente. Riga :"+num_row);
				}
				if(type.equals(INTEGER) && hash_row_type.containsValue(INTEGER)  ) {
					throw new LPException("La variabile TYPE non puo' assumere di nuovo il valore INTEGER. Questo valore e' stato impostato precendente. Riga :"+num_row);
				}
				if(type.equals(SEMICONT) && hash_row_type.containsValue(SEMICONT)  ) {
					throw new LPException("La variabile TYPE non puo' assumere di nuovo il valore SEMICONT. Questo valore e' stato impostato precendente. Riga :"+num_row);
				}
				
				
				String row=source_sparse.getString("ROW_");	
				if(row==null) {
					throw new LPException("Ogni valore della variabile TYPE ("+type+") deve essere associato ad un valore di ROW_ non null. Riga :"+num_row); 
				}
				if(hash_row_type.containsKey(row)) {
					throw new LPException("Il valore di ROW_ = ("+row+") e' stato gia' definito in precedenza con TYPE di tipo:"+hash_row_type.get(row)+". Riga :"+num_row); 
				}
				hash_row_type.put(row, type);
			}
			else {
				String col=source_sparse.getString("COL_");
				String row=source_sparse.getString("ROW_");
				Double coef=source_sparse.getDouble("COEF");
				
				
				if(row==null) {
					throw new LPException("La variabile ROW_ deve essere sempre valorizzata. Riga :"+num_row); 
				}
				if(col==null) {
					throw new LPException("La variabile COL_ deve essere valorizzata se non e' presente la variabile TYPE. Riga :"+num_row); 
				}
				col=col.toUpperCase();
				
				tree_col.add(col);
				
				HashMap<String, Double> hash_col_val;
				if(hash_row_col.containsKey(row)) { 
					hash_col_val=hash_row_col.get(row);
					hash_col_val.put(col, coef);
				}
				else { 
					hash_col_val=new HashMap<String, Double>();
					hash_col_val.put(col, coef);
					hash_row_col.put(row, hash_col_val);
				}
			}
		}	
		
		//controllo che ogni row di tipo EQ,LE,GE abbia valorizzato coef
		for(String row2:hash_row_type.keySet()) {
			String type2=hash_row_type.get(row2);
			if( type2.equals(LE) || type2.equals(EQ) || type2.equals(GE) || type2.equals(MAX) || type2.equals(MIN)) {
				HashMap<String, Double> hash_col_val2=hash_row_col.get(row2);
				for(String col2:tree_col) {
					Double coef2=hash_col_val2.get(col2);
					if( !col2.equals("RHS") && coef2==null) hash_col_val2.put(col2, 0.0); //se manca vuol dire che e' a zero
				}
			}
		}
		
		//Controlli da fare : a) ogni vincolo di tipo EQ,LE,Ge deve avere un RHS 
		
		
		for(String row2:hash_row_type.keySet()) {
			String type2=hash_row_type.get(row2);
			if( type2.equals(LE)    || type2.equals(EQ)     || type2.equals(GE))  {
				HashMap<String, Double> hash_col_val2=hash_row_col.get(row2);
				boolean exist_rhs=false;
				for(String col2:hash_col_val2.keySet()) {
					if(col2.equals("RHS")) exist_rhs=true;
					//System.out.println("ROW:"+row2 +" COL:"+col2 );
				}
				if(!exist_rhs) throw new SimplexException("Il rigo "+row2+" di tipo ("+type2+") non ha associato nessun valore RHS");
			}
		}
		
		
		for(String row:hash_row_col.keySet()) {
			if(!hash_row_type.containsKey(row)) {
				throw new LPException("Il valore di ROW_ = ("+row+") non ha associato nessun valore TYPE ."); 
			}
		}	
		
		//CONTROLLARE CHE ESISTA ALMENO UN MAX O MIN
		if(!(hash_row_type.containsValue(MAX) || hash_row_type.containsValue(MIN)))  {
			throw new LPException("Non e' presente nessun valore della variabile TYPE rappresentante la f.o (MAX o MIN). "); 
		}
		return createMilpFromHashTables( hash_row_type,hash_row_col,tree_col) ;
	}
	
	
	
	private static MilpProblem createMilpFromHashTables(HashMap<String,String> hash_row_type,
											  HashMap<String,HashMap<String, Double>> hash_row_col,
											  TreeSet<String> tree_col) throws LPException  {
		
		int size=tree_col.size();
		int N=size;
		if(tree_col.contains("RHS")) N=size-1;
		//System.out.println("DIME::"+N);
		MilpProblem milp_original=new MilpProblem(N);
		int _j=0;
		HashMap<String,Integer> link_name_index=new HashMap<String,Integer>();
		for(String nome_var:tree_col)  {
			 if(!nome_var.equals("RHS")) {
				 milp_original.setNameVar(_j,nome_var);
				 link_name_index.put(nome_var, _j);
				 _j++;
			 }
		 }
		
		for(String row:hash_row_col.keySet()) { 
			String type_row=hash_row_type.get(row);
			HashMap<String,Double> hah_col_val=hash_row_col.get(row);
			
			if(type_row.equals(MAX) || type_row.equals(MIN)) {
				milp_original.setTargetObjFunction(type_row);

				for(String col:hah_col_val.keySet()) { 
					if(!col.equals("RHS")) { 
						milp_original.setCjOF(link_name_index.get(col), hah_col_val.get(col));
						//System.out.println("xxx CIJ::"+link_name_index.get(col)+"::"+hah_col_val.get(col));
					}
				}
			}
			
			else if(type_row.equals(LE) || type_row.equals(GE) || type_row.equals(EQ)) {
				InternalConstraint constraint_i=new InternalConstraint(N) ;
				constraint_i.setName(row);
				for(String col:hah_col_val.keySet()) { 
					if(col.equals("RHS")) { 
						 Double double_b=hah_col_val.get(col);
						 if(double_b==null) throw new LPException("I coefficienti Bi (RHS) non possono essere missing. ");
						 constraint_i.setBi(double_b);
						 //System.out.println("xxx RHS::"+double_b);
					}
					else {
						Double double_val=hah_col_val.get(col);
						if(double_val==null) throw new LPException("I valori Aij della matrice dei coefficienti relativi ai vincoli (EQ,LE,GE) non possono essere missing (null). Se la variabile ha coefficiente zero inserire zero");
						constraint_i.setAij(link_name_index.get(col), double_val);
						//System.out.println("xxx AIJ::"+link_name_index.get(col)+"::"+double_val);

						if(type_row.equals(LE)) constraint_i.setType(InternalConstraint.TYPE_CONSTR.LE);
						else if(type_row.equals(GE)) constraint_i.setType(InternalConstraint.TYPE_CONSTR.GE);
						else if(type_row.equals(EQ)) constraint_i.setType(InternalConstraint.TYPE_CONSTR.EQ);
					}
				}
				milp_original.addConstraint(constraint_i);
			}
			
			else if(type_row.equals(UPPER) || type_row.equals(LOWER) ) {
				
				for(String col:hah_col_val.keySet()) { 
					if(!col.equals("RHS")) { 
						Var xj=milp_original.getVar(link_name_index.get(col));
						Double bound_val=hah_col_val.get(col);
						if(type_row.equals(UPPER)) xj.setUpper(bound_val);
						if(type_row.equals(LOWER)) xj.setLower(bound_val);
						//System.out.println("xxx "+type_row+"::"+link_name_index.get(col)+"::"+bound_val);
					}
				}
			}
			
			
			else if(type_row.equalsIgnoreCase(BINARY) || type_row.equalsIgnoreCase(INTEGER) || type_row.equalsIgnoreCase(SEMICONT)) {

				for(String col:hah_col_val.keySet()) { 
					if(!col.equals("RHS")) { 

						Var xj=milp_original.getVar(link_name_index.get(col));
						Double type_var=hah_col_val.get(col);
						if(type_var!=null && type_var==1.0) {
							//System.out.println("VAR  "+_j +"  "+type_row);
							if(type_row.equalsIgnoreCase(INTEGER)) { 
								if(xj.getType()==Var.TYPE_VAR.BINARY) throw new LPException("La variabile "+col+" non puo' essere INTEGER  e' stata gia' definita BYNARY");
								xj.setType(Var.TYPE_VAR.INTEGER);
							}
							if(type_row.equalsIgnoreCase(BINARY))  {
								if(xj.getType()==Var.TYPE_VAR.INTEGER) throw new LPException("La variabile "+col+" non puo' essere BYNARY e' stata gia' definita INTEGER");
								xj.setType(Var.TYPE_VAR.BINARY);
							}
							if(type_row.equalsIgnoreCase(SEMICONT)) { 
								if(xj.getType()==Var.TYPE_VAR.BINARY) throw new LPException("La variabile "+col+" non puo' essere SEMICONT  e' stata gia' definita BYNARY");
								xj.setSemicon(true);
							}
							
							
						}
						else if(type_var==null || type_var!=0.0) {
							if(type_row.equalsIgnoreCase(INTEGER)) throw new LPException("Per definire o no una variabile INTERA si deve valorizzare la riga "+row+" solo con i valori (0,1)");
							if(type_row.equalsIgnoreCase(BINARY))  throw new LPException("Per definire o no una variabile BINARIA si deve valorizzare la riga dei "+row+" solo con i valori (0,1)");
							if(type_row.equalsIgnoreCase(SEMICONT))  throw new LPException("Per definire o no una variabile SEMICONTINUA si deve valorizzare la riga dei "+row+" solo con i valori (0,1)");
						}
					}
				}
			}
		}	
		return milp_original;
	}
	
	
	private static void checkDimensionProblem(LinearObjectiveFunction f,
											  ArrayList<Constraint> constraints) throws SimplexException {


		double[] c=f.getC();
		int n=c.length;

		for(Constraint constraint:constraints) {
			if(n!= constraint.getAj().length) {
				throw new SimplexException("La dimensione del numero delle colonne di un vincolo "+
						constraint.getRel()+" non coincide con la dimensione N:"+n+" della funzione obiettivo");		 
			}
		}
	}
}
