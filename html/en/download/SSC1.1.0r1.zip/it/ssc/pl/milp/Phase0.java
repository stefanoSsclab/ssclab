package it.ssc.pl.milp;

import it.ssc.vector_spaces.Matrixe;

abstract class Phase0 {

	protected int basis[];
	protected Matrixe table_exended;
	protected long iteration =0; 
	private final int _M;
	private final int _N;
	protected EPSILON epsilon;
	protected EPSILON cepsilon;

	protected Phase0(int _M, int _N,EPSILON epsilon,EPSILON cepsilon) {
		this(_M, _N, epsilon) ;
		this.cepsilon=cepsilon;
	}

	protected Phase0(int _M, int _N,EPSILON epsilon) {
		this._M=_M; //righe 
		this._N=_N; //colonne
		this.epsilon=epsilon;
	}

	public long getNumIteration() {
		return iteration;
	}

	public abstract SolutionType resolve(long num_iteration) ;

	protected void setBases(int row,int in) {
		basis[row] = in;
	}


	public double getValueZ() {
		return  -(table_exended.getCell(_M, _N));
	}


	protected void pivoting(int out, int in) {
		double[][] mat_appo=table_exended.getMatrixe();
		double value;
		for (int i = 0; i <= _M; i++) {
			for (int j = 0; j <= _N; j++) {
				if (i != out && j != in) {
					value = (mat_appo[out][ j] * mat_appo[i][in]) / mat_appo[out][ in];
					//value = value / mat_appo[out][ in];
					mat_appo[i][ j] = mat_appo[i][ j] - value;
				}
			}
		}

		for (int i = 0; i <= _M; i++) {
			if (i != out) {
				mat_appo[i][ in]= 0.0;
			}
		}

		for (int j = 0; j <= _N; j++) {
			if (j != in) {
				mat_appo[out][ j ] = mat_appo[out][ j]/ mat_appo[out][ in];
			}
		}
		mat_appo[out][ in] = 1.0;

	}


	protected int test_var_outgoing(int var_incoming) {
		int row_var_outgoing = -1;
		double bottleneck= 0, candidate_bottleneck=0;
		double[][] mat_appo=table_exended.getMatrixe();

		for (int i = 0; i < _M; i++) {
			if (mat_appo[i][var_incoming] <= epsilon.getValue()) {
				continue;
			}

			candidate_bottleneck = mat_appo[i][_N]/ mat_appo[i][ var_incoming];

			if (row_var_outgoing == -1) {
				row_var_outgoing = i;
				bottleneck = candidate_bottleneck;
			}
			else  if (candidate_bottleneck < (bottleneck) ) {
				row_var_outgoing = i;
				bottleneck = candidate_bottleneck;
			}
		}
		return row_var_outgoing;
	}


	protected int test_var_incoming() {
		double value_var_incoming=0.0;
		int index_var_incoming = 0;
		double[][] mat_appo=table_exended.getMatrixe();
		for (int j = 0; j < _N; j++) {
			//controllo se c'e' un qualche coefficente sulla f.o. maggiore di ZERO
			//naturalmente relativo alle variabili non basiche
			if (mat_appo[_M][ j]> (value_var_incoming) ) { 
				value_var_incoming = mat_appo[_M][ j]; 
				index_var_incoming = j;
			}
		}

		//if (new BigDecimal(value_var_incoming).setScale(SCALE, RoundingMode.HALF_DOWN).doubleValue() > 0.0) return index_var_incoming;
		if (value_var_incoming > epsilon.getValue() ) return index_var_incoming;
		else return -1;  // optimal
	}

	protected int test_var_incoming_bland() {
		for (int j = 0; j < _N; j++) {
			//controllo se c'e' un qualche coefficente sull f.o. maggiore di ZERO
			//naturalmente relativo alle variabili non basiche
			if (table_exended.getCell(_M, j) > epsilon.getValue()) {
				return j;
			}
		}
		return -1; // ottimo
	}



	protected  boolean isBaseDegenerate() {
		int m=table_exended.getNrow()-1;
		int n_m=table_exended.getNcolumn()-1;
		double value;
		for (int i = 0; i < m; i++) {
			value=table_exended.getCell(i,n_m);
			if( Math.abs(value) < epsilon.getValue()) return true;   //ATTENZIONE PRIMA == ZERO 
		}
		return false;
	}

	private void printTable() {
		for(int _i=0;_i<table_exended.getNrow();_i++) {
			System.out.println("");
			for(int _j=0;_j<table_exended.getNcolumn();_j++) {
				double val=table_exended.getCell(_i, _j);
				System.out.printf("\t : %7.14f",val);
			}
		}
		System.out.println("");
	}

	private void printBases() {

		System.out.println("F2 dim:" + basis.length);
		for (int i = 0; i < basis.length; i++) {
			System.out.println("F2 X" + (basis[i]+1));
		}
	}

	public int[] getBasisClone() {
		return basis.clone();
	}
}
