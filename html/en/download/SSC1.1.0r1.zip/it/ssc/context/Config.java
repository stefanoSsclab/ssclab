package it.ssc.context;

public interface Config {
	
	public String getPathWorkArea(); 
	
	/**
	 * Questa chiamata setta il path dell'area di work  per 
	 * le nuove sessioni SSC che verranno create a partire da tale configurazione.  
	 * Quelle create antecedentemente a tale chiamata mantengono la work 
	 * precedentemente definita. 
	 * 
	 * @param path_work
	 */
	public void setPathWorkArea(String path_work); 
	
}
